CREATE TABLE LOGIN_DETAILS (
_id varchar(256) NOT NULL,
userId varchar(256) NOT NULL,
user_password varchar(256) NOT NULL,
active tinyint NOT NULL
);
GO
