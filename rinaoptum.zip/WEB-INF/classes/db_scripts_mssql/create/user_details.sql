CREATE TABLE dbo.USER_DETAILS (
_id varchar(256) NOT NULL,
firstName varchar(256) NOT NULL,
lastName varchar(256) NOT NULL,
user_address varchar(256) NOT NULL,
phoneNo varchar(256) NOT NULL,
emailId varchar(256) NOT NULL,
userName varchar(256) NOT NULL,
url_path varchar(256) NOT NULL,
active tinyint NOT NULL
);
GO