(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"padding: 5px;\" >\n  <amexio-layout-grid [layout]=\"gridcss\">\n    <amexio-grid-item [min-content]=\"true\" [name]=\"'rinatenantbranding'\">\n      <company-logo></company-logo>\n    </amexio-grid-item>\n    <amexio-grid-item  [name]=\"'rinacustomerdemographics'\">\n             <customer-demo-graphic></customer-demo-graphic> \n\n    </amexio-grid-item>\n    <amexio-grid-item [name]=\"'rinaproducts'\" style=\"margin: -5px 0px;\">\n             <product style=\"display: block; margin: 0px -5px -5px -5px;\"></product> \n\n    </amexio-grid-item>\n    <amexio-grid-item [min-content]=\"true\" [name]=\"'rinaworkflows'\">\n       <center-left></center-left> \n    </amexio-grid-item>\n    <amexio-grid-item [name]=\"'rinacentertablayout'\">\n      <center-middle></center-middle>\n    </amexio-grid-item>\n    <amexio-grid-item [hc-enabled]=\"false\" [hc-direction]=\"'right'\" [name]=\"'ringleftblock'\">\n        <top-right></top-right> \n    </amexio-grid-item>\n  </amexio-layout-grid>\n</div>\n<amexio-spinner [show]=\"_sharedService.showLoader\" [type]=\"'rectanglebounce'\" [vertical-position]=\"'top'\" [horizontal-position]=\"'center'\" [color]=\"'yellow'\">\n</amexio-spinner>\n <amexio-notification\n        [data]=\"_sharedService.errorMsgData\"\n        [vertical-position]=\"'top'\"\n        [horizontal-position]=\"'right'\"\n        [close-on-escape] =\"true\"\n        [background-color]=\"'red'\"\n        [auto-dismiss-msg]=\"true\"\n        [auto-dismiss-msg-interval]=\"8000\">\n      </amexio-notification>\n\n      <amexio-notification\n      [data]=\"_sharedService.successMsgData\"\n      [vertical-position]=\"'top'\"\n      [horizontal-position]=\"'right'\"\n      [close-on-escape] =\"true\"\n      [background-color]=\"'green'\"\n      [auto-dismiss-msg]=\"true\"\n      [auto-dismiss-msg-interval]=\"8000\">\n    </amexio-notification>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! amexio-ng-extensions */ "./node_modules/amexio-ng-extensions/bundles/amexio-ng-extensions.umd.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */



var AppComponent = /** @class */ (function () {
    function AppComponent(_sharedService, _gridlayoutService) {
        this._sharedService = _sharedService;
        this._gridlayoutService = _gridlayoutService;
        this.gamificationExpand = true;
        this.helpExpand = true;
        this.badge = '';
        this.gridcss = 'RINALAYOUT';
        this.showPrev = false;
        this.showNext = false;
    }
    AppComponent.prototype.setLayout = function () {
        this.gridcss = this.gridcss + "-" + new Date().getTime();
        this.rinalayoutConfigDesktop1 = new amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["GridConfig"](this.gridcss, amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["GridConstants"].Desktop)
            .addlayout(["rinatenantbranding", "rinacustomerdemographics", "rinaproducts", "rinaproducts", "ringleftblock"])
            .addlayout(["rinaworkflows", "rinacentertablayout", "rinacentertablayout", "rinacentertablayout", "rinacentertablayout"]);
        this._gridlayoutService.createLayout(this.rinalayoutConfigDesktop1);
    };
    AppComponent.prototype.ngOnInit = function () {
        this.setLayout();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('productspanel', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], AppComponent.prototype, "productspanel", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('customerdemographics', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], AppComponent.prototype, "customerdemographics", void 0);
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["AmexioGridLayoutService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! amexio-ng-extensions */ "./node_modules/amexio-ng-extensions/bundles/amexio-ng-extensions.umd.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_layout_components_comapny_logo_company_logo_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../app/layout-components/comapny-logo/company.logo.component */ "./src/app/layout-components/comapny-logo/company.logo.component.ts");
/* harmony import */ var _app_layout_components_customer_demographic_customer_demographic_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../app/layout-components/customer-demographic/customer-demographic.component */ "./src/app/layout-components/customer-demographic/customer-demographic.component.ts");
/* harmony import */ var _app_layout_components_top_right_top_right_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../app/layout-components/top-right/top-right.component */ "./src/app/layout-components/top-right/top-right.component.ts");
/* harmony import */ var _app_layout_components_center_left_center_left_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../app/layout-components/center-left/center-left.component */ "./src/app/layout-components/center-left/center-left.component.ts");
/* harmony import */ var _app_layout_components_center_left_searchbox_searchbox_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../app/layout-components/center-left/searchbox/searchbox.component */ "./src/app/layout-components/center-left/searchbox/searchbox.component.ts");
/* harmony import */ var _app_layout_components_center_middle_center_middle_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../app/layout-components/center-middle/center-middle.component */ "./src/app/layout-components/center-middle/center-middle.component.ts");
/* harmony import */ var _app_layout_components_product_details_product_details_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../app/layout-components/product-details/product-details.component */ "./src/app/layout-components/product-details/product-details.component.ts");
/* harmony import */ var _layout_components_alert_window_alert_window_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./layout-components/alert-window/alert-window.component */ "./src/app/layout-components/alert-window/alert-window.component.ts");
/* harmony import */ var _layout_components_formulary_lookup_formulary_lookup_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./layout-components/formulary-lookup/formulary-lookup.component */ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _app_layout_components_center_left_searchbox_searchbox_component__WEBPACK_IMPORTED_MODULE_12__["SearchBoxComponent"], _app_layout_components_product_details_product_details_component__WEBPACK_IMPORTED_MODULE_14__["ProductDetailsComponent"], _app_layout_components_comapny_logo_company_logo_component__WEBPACK_IMPORTED_MODULE_8__["CompanyLogoComponent"], _app_layout_components_center_middle_center_middle_component__WEBPACK_IMPORTED_MODULE_13__["CenterMiddleComponent"], _app_layout_components_center_left_center_left_component__WEBPACK_IMPORTED_MODULE_11__["CenterLeftComponent"], _app_layout_components_customer_demographic_customer_demographic_component__WEBPACK_IMPORTED_MODULE_9__["CustomerDemoGraphicComponent"], _app_layout_components_top_right_top_right_component__WEBPACK_IMPORTED_MODULE_10__["TopRightComponent"], _layout_components_alert_window_alert_window_component__WEBPACK_IMPORTED_MODULE_15__["AlertWindowComponent"], _layout_components_formulary_lookup_formulary_lookup_component__WEBPACK_IMPORTED_MODULE_16__["FormularyLookupComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioDashBoardModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioEnterpriseModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioWidgetModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["DatePipe"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/constants/service.constant.ts":
/*!***********************************************!*\
  !*** ./src/app/constants/service.constant.ts ***!
  \***********************************************/
/*! exports provided: BASE_URL, SERVICE_URL, SERVICE_URL1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BASE_URL", function() { return BASE_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICE_URL", function() { return SERVICE_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICE_URL1", function() { return SERVICE_URL1; });
var BASE_URL = "http://localhost:3000/api";
var SERVICE_URL = {
    MNR_SEARCH: BASE_URL + '',
    DEMOGRAPHIC_DATA: BASE_URL + '',
    MEMEBER_DETAILS_DATA: BASE_URL + '',
    PLAN_DETAILS_DATA: BASE_URL + '',
    BILLING_SUMMARY_DETAILS_DATA: BASE_URL + '',
    COVERAGE_DETAILS: BASE_URL + '',
    MNR_CLAIMS_DATA: BASE_URL + '',
    REJECTED_CLIAMS: BASE_URL + '',
    FORMULARY_LOOKUP: BASE_URL + '',
    OVATION_PART_D: BASE_URL + '',
    DRUG_COST_ESTIMATOR: BASE_URL + '',
    GET_COUNTY: BASE_URL + '',
    SENT_COUNTY: BASE_URL + '',
    DRUG_DETAILS: BASE_URL + '',
    PHARMACY_TABLE: BASE_URL + ''
};
var SERVICE_URL1 = {
    OVATION_PART_D: BASE_URL + 'assets/data/MnrSearch.json',
    DRUG_COST_ESTIMATOR: BASE_URL + 'assets/data/copay.json',
    MNR_SEARCH: BASE_URL + 'assets/data/MnrSearch.json',
    DEMOGRAPHIC_DATA: BASE_URL + 'assets/data/demographicDetails.json',
    MEMEBER_DETAILS_DATA: BASE_URL + 'assets/data/memberDetails.json',
    PLAN_DETAILS_DATA: BASE_URL + 'assets/data/planDetails.json',
    BILLING_SUMMARY_DETAILS_DATA: BASE_URL + 'assets/data/billingsummarydetails.json',
    COVERAGE_DETAILS: BASE_URL + 'assets/data/coverageDetails.json',
    MNR_CLAIMS_DATA: BASE_URL + 'assets/data/MNrclaims.json',
    REJECTED_CLIAMS: BASE_URL + 'assets/data/rejectedclaims.json',
    FORMULARY_LOOKUP: BASE_URL + 'assets/data/formularylookup.json',
    GET_COUNTY: BASE_URL + 'assets/data/getcounty.json',
    SENT_COUNTY: BASE_URL + 'assets/data/sentcounty.json',
    DRUG_DETAILS: BASE_URL + 'assets/data/drugdetails.json',
    PHARMACY_TABLE: BASE_URL + 'assets/data/pharmacytable.json'
};


/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-window-ce [(show)]=\"_sharedService.showAlertWindow\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\"\n    width=\"60%\" align=\"start\">\n    <amexio-header-ce align=\"left\" vertical-align=\"top\">\n        <amexio-label size=\"medium-bold\">Alert</amexio-label>\n    </amexio-header-ce>\n    <amexio-body-ce>\n        <ng-container *ngIf=\"rejectedclaimsData && rejectedclaimsData.length>0 ;else elseBlock\">\n            <amexio-box amexioColorPalette [color-palette]=\"'classic'\" [gradient]=\"true\" border=\"left\"  padding=\"true\">\n                <amexio-label>{{message}}</amexio-label><br>\n                <amexio-label>{{confirmation}}</amexio-label>\n            </amexio-box>\n            <br>\n            <b style=\"color:red\">Member has a rejected claim!</b>\n            <amexio-datagrid [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"rejectedclaimsData\">\n                <amexio-data-table-column [width]=\"35\" [data-index]=\"'servicedate'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Service Date'\">\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"35\" [data-index]=\"'rxnumber'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Provider'\">\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"30\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Status'\">\n                </amexio-data-table-column>\n            </amexio-datagrid>\n        </ng-container>\n        <ng-template #elseBlock>\n            <b style=\"color:red\">Member has no rejected claims</b>\n        </ng-template>\n    </amexio-body-ce>\n</amexio-window-ce>"

/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.ts ***!
  \**************************************************************************/
/*! exports provided: AlertWindowComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertWindowComponent", function() { return AlertWindowComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AlertWindowComponent = /** @class */ (function () {
    function AlertWindowComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.rejectedclaimsData = [];
        this._sharedService.rejectedClaimData.subscribe(function (data) {
            if (data) {
                setTimeout(function () {
                    _this.rejectedclaimsData = Object.assign([], data.rejectedclaimdata);
                    _this.message = data.message;
                    _this.confirmation = data.confirmation;
                    _this._sharedService.showAlertWindow = true;
                    _this._sharedService.showAlert = true;
                }, 100);
            }
        });
    }
    AlertWindowComponent.prototype.ngOnInit = function () {
    };
    AlertWindowComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'alert-window',
            template: __webpack_require__(/*! ./alert-window.component.html */ "./src/app/layout-components/alert-window/alert-window.component.html"),
            styles: [__webpack_require__(/*! ./alert-window.component.css */ "./src/app/layout-components/alert-window/alert-window.component.css")]
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], AlertWindowComponent);
    return AlertWindowComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/center-left/center-left.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/center-left/center-left.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"true\" [footer]=\"true\" [footer-align]=\"'center'\" [body-height]=\"50\">\n  <amexio-header>\n    MEMBER SEARCH\n  </amexio-header>\n  <amexio-body>\n    <amexio-row>\n      <amexio-column [size]=\"12\">\n        <search-box (search)=\"searchHandle($event)\" [isSearchDisble]=\"_sharedService.searchdisble\"></search-box>\n      </amexio-column>\n    </amexio-row>\n    <amexio-row>\n      <amexio-column [size]=\"12\">\n        <div style=\"padding: 2px;\">\n          <amexio-button [label]=\"'OVATION PART D'\" [type]=\"'theme-color'\" (onClick)=\"workflowHandle(2)\" [tooltip]=\"'large'\" [block]=\"true\"\n            [disabled]=\"!(this._sharedService.memberId && this._sharedService.memberId.length>0)\">\n          </amexio-button>\n          <amexio-row>\n            <amexio-column [size]=12>\n            </amexio-column>\n          </amexio-row>\n          <amexio-button [label]=\"'DRUG COST ESTIMATOR'\" [type]=\"'theme-color'\" (onClick)=\"workflowHandle(3)\" [tooltip]=\"'large'\" [block]=\"true\"\n            [disabled]=\"!(this._sharedService.memberId && this._sharedService.memberId.length>0)\">\n          </amexio-button>\n        </div>\n      </amexio-column>\n    </amexio-row>\n  </amexio-body>\n  <amexio-action>\n    <amexio-row>\n      <amexio-column size=\"12\">\n        <div style=\"display: inline-flex; justify-content: center; width:100%;\">\n          <i style=\"margin: 5px\" class=\"fa fa-sun-o\"></i>\n          <amexio-darkmode [size]=\"'small'\" [type]=\"2\"></amexio-darkmode>\n          <i style=\"margin: 5px\" class=\"fa fa-moon-o\"></i>\n        </div>\n      </amexio-column>\n    </amexio-row>\n  </amexio-action>\n</amexio-card>\n<amexio-window-ce [(show)]=\"showdrugcostestimator\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"80%\"\n  align=\"start\" (close)=\"onCloseClick($event)\">\n  <amexio-header-ce align=\"left\" vertical-align=\"top\">\n    <amexio-layout-columns alignment=\"start\" [orientation]=\"'horizontal'\" [border]=\"false\">\n      <amexio-layout-item>\n        <amexio-label size=\"medium-bold\">Drug Cost Estimator</amexio-label>\n      </amexio-layout-item>\n    </amexio-layout-columns>\n  </amexio-header-ce>\n  <amexio-body-ce>\n      <amexio-row *ngIf=\"(!costFlag && !pharmacyFlag && countyFlag)\">\n        <amexio-column size=\"6\" fit=\"true\">\n          <amexio-dropdown [(ngModel)]=\"drugCostModel.county\" [place-holder]=\"'Please Choose'\" name=\"county\" [allow-blank]=\"false\"\n            [disabled]=\"(countyData && countyData.length<0)\" [error-msg]=\"'County'\" [data]=\"countyData\" [display-field]=\"'primarydisplay'\"\n            [value-field]=\"'primarydisplay'\" [search]=\"true\" (onSingleSelect)=\"oncostClick($event,1)\">\n          </amexio-dropdown>\n        </amexio-column>\n        <amexio-column size=\"6\" fit=\"true\">\n        </amexio-column>\n        <amexio-column size=\"6\" fit=\"true\">\n          <amexio-text-input [field-label]=\"'Drug Name'\" name=\"name\"  (keyup)=\"ondrugnameClick($event)\" [place-holder]=\"'Enter Drug Name'\"\n            [(ngModel)]=\"drugCostModel.drugname\">\n          </amexio-text-input>\n        </amexio-column>\n        <amexio-column size=\"6\" fit=\"true\">\n        </amexio-column>\n      </amexio-row>\n      \n      <amexio-row *ngIf=\"countyFlag && drugFlag && !costFlag\">\n        <amexio-column size=\"3\" fit=\"true\">\n          <amexio-dropdown [field-label]=\"'Dosage'\" [(ngModel)]=\"drugCostModel.dosage\" [place-holder]=\"'Please Choose'\" name=\"dosage\"\n            [disabled]=\"(dosageData && dosageData.length<0)\" [allow-blank]=\"false\" [error-msg]=\"'Dosage'\" [data]=\"dosageData\" [display-field]=\"'primarydisplay'\" [value-field]=\"'primarydisplay'\"\n            [search]=\"true\" (onSingleSelect)=\"oncostClick($event,2)\">\n          </amexio-dropdown>\n        </amexio-column>\n        <amexio-column size=\"3\" fit=\"true\">\n          <amexio-dropdown [field-label]=\"'Frequency'\" [(ngModel)]=\"drugCostModel.frequency\" [place-holder]=\"'Please Choose'\" name=\"frequency\"\n            [allow-blank]=\"false\" [error-msg]=\"'Frequency'\" [data]=\"frequencyData\"  [disabled]=\"(frequencyData && frequencyData.length<0)\" [display-field]=\"'primarydisplay'\" [value-field]=\"'primarydisplay'\"\n            [search]=\"true\" (onSingleSelect)=\"oncostClick($event,3)\">\n          </amexio-dropdown>\n        </amexio-column>\n        <amexio-column size=\"3\" fit=\"true\">\n          <amexio-text-input [field-label]=\"'Quantity'\" [(ngModel)]=\"drugCostModel.quantity\" [place-holder]=\"'Enter quantity'\" name=\"quantity\"\n            [allow-blank]=\"false\" [error-msg]=\"'quantity'\" (keyup)=\"oncostClick($event,4)\">\n          </amexio-text-input>\n        </amexio-column>\n        <amexio-column size=\"3\" fit=\"true\">\n          <amexio-dropdown *ngIf=\"(packageData && packageData.length>0)\" [field-label]=\"'Package'\" [(ngModel)]=\"drugCostModel.package\"\n           [disabled]=\"(packageData && packageData.length<0)\"  [place-holder]=\"'Please Choose'\" name=\"package\" [allow-blank]=\"false\" [error-msg]=\"'package'\" [data]=\"packageData\"\n            [display-field]=\"'primarydisplay'\" [value-field]=\"'primarydisplay'\" [search]=\"true\" (onSingleSelect)=\"oncostClick($event,5)\">\n          </amexio-dropdown>\n        </amexio-column>\n      </amexio-row>\n      <amexio-row *ngIf=\"!pharmacyFlag  && !costFlag\">\n        <amexio-column size=\"12\" fit=\"true\">\n          <amexio-button [disabled]=\"costSearchFlag\" [label]=\"'Search'\" [type]=\"'theme-color'\" (onClick)=\"onSearchClick()\" [tooltip]=\"'search'\">\n          </amexio-button>\n        </amexio-column>\n      </amexio-row>\n      <amexio-row *ngIf=\"(pharmacyFlag && !countyFlag && !drugFlag && !costFlag)\">\n        <amexio-column size=\"12\" fit=\"true\">\n          <amexio-datagrid [height]=\"400\" class=\"claimgrid\" [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"pharmacyData\">\n            <amexio-data-table-column [width]=\"10\" [data-index]=\"''\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"''\">\n              <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n                <amexio-button (onClick)=\"onPharmacyClick(row)\" [label]=\"'Select'\" [type]=\"'theme-color'\">\n                </amexio-button>\n              </ng-template>\n            </amexio-data-table-column>\n            <amexio-data-table-column [width]=\"50\" [data-index]=\"'pharmacy'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Pharmacy'\">\n                <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n                    <div [innerHTML]=\"row.pharmacy\"></div>\n                  </ng-template>               \n            </amexio-data-table-column>\n            <amexio-data-table-column [width]=\"30\" [data-index]=\"'pharmacytype'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Pharmacy Type'\">\n                <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n                    <div [innerHTML]=\"row.pharmacytype\"></div>\n                  </ng-template>\n            </amexio-data-table-column>\n            <amexio-data-table-column [width]=\"10\" [data-index]=\"'retails'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Distance'\">\n                <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n                    <div [innerHTML]=\"row.retails\"></div>\n                  </ng-template>\n            </amexio-data-table-column>\n          </amexio-datagrid>\n        </amexio-column>\n      </amexio-row>\n    <amexio-row *ngIf=\"!pharmacyFlag && !countyFlag && !drugFlag && costFlag\">\n      <amexio-column size=\"12\" fit=\"fit\">\n        <amexio-box amexioColorPalette [color-palette]=\"'classic'\" [gradient]=\"true\" border=\"left\" padding=\"true\">\n          <amexio-label><b> Copay:</b> {{copay}}</amexio-label><br>\n          <amexio-label><b>DrugCostEstimator: </b> {{cost}}  ( Total calendar year cost )</amexio-label>\n        </amexio-box>\n      </amexio-column>\n    </amexio-row>\n  </amexio-body-ce>\n</amexio-window-ce>"

/***/ }),

/***/ "./src/app/layout-components/center-left/center-left.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/layout-components/center-left/center-left.component.ts ***!
  \************************************************************************/
/*! exports provided: CenterLeftComponent, DrugCostModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CenterLeftComponent", function() { return CenterLeftComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DrugCostModel", function() { return DrugCostModel; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/rest.call.service */ "./src/app/services/rest.call.service.ts");
/* harmony import */ var src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/constants/service.constant */ "./src/app/constants/service.constant.ts");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 4/6/19.
 */






var CenterLeftComponent = /** @class */ (function () {
    function CenterLeftComponent(date, sanitizer, _rCallService, _sharedService) {
        var _this = this;
        this.date = date;
        this.sanitizer = sanitizer;
        this._rCallService = _rCallService;
        this._sharedService = _sharedService;
        // showdrugcostestimatorurl: any;
        this.workflowList = [];
        this.countyData = [];
        this.dosageData = [];
        this.frequencyData = [];
        this.packageData = [];
        this.pharmacyData = [];
        this.costSearchFlag = true;
        this.drugDetails = [];
        this.costFlag = false;
        this.pharmacyFlag = false;
        this.countyFlag = true;
        this.drugFlag = false;
        this.drugCostModel = new DrugCostModel();
        this._sharedService.countyData.subscribe(function (data) {
            if (data != null) {
                _this.countyData = [];
                data.forEach(function (obj) {
                    if (obj["dropdownoption"]) {
                        obj["dropdownoption"] = obj.dropdownoption.split("+");
                        obj["dropdownoption"] = obj["dropdownoption"].filter(function (msg) { return msg.trim().length > 0; });
                    }
                });
                data[0].dropdownoption.forEach(function (obj) {
                    var tempObj = {
                        "primarydisplay": ""
                    };
                    tempObj.primarydisplay = obj;
                    _this.countyData.push(tempObj);
                });
                _this.costFlag = false;
                _this.countyFlag = true;
                _this.drugFlag = false;
                _this.pharmacyFlag = false;
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.pharmacyDetails.subscribe(function (data) {
            if (data != null) {
                _this.pharmacyData = [];
                _this.pharmacyData = data;
                if (_this.pharmacyData) {
                    var max = 10;
                    _this.pharmacyData.forEach(function (object, index) {
                        object['index'] = index;
                    });
                }
                _this.costFlag = false;
                _this.countyFlag = false;
                _this.drugFlag = false;
                _this.pharmacyFlag = true;
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.drugCost.subscribe(function (data) {
            if (data != null) {
                _this.copay = data[0].copay;
                _this.cost = data[0].drugcostestimator;
                _this.costFlag = true;
                _this.countyFlag = false;
                _this.drugFlag = false;
                _this.pharmacyFlag = false;
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.drugDetails.subscribe(function (data) {
            if (data != null) {
                _this.drugDetails = data;
                data.forEach(function (obj) {
                    if (obj["dosage"] || obj["frequency"]) {
                        obj["dosage"] = obj.dosage.split("+");
                        obj["frequency"] = obj.frequency.split("+");
                        obj["dosage"] = obj["dosage"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["frequency"] = obj["frequency"].filter(function (msg) { return msg.trim().length > 0; });
                    }
                    if (obj["package"]) {
                        obj["package"] = obj.package.split("+");
                        obj["package"] = obj["package"].filter(function (msg) { return msg.trim().length > 0; });
                    }
                });
                _this.getDrugDetails(data);
            }
            _this.countyFlag = true;
            _this.drugFlag = true;
            _this.costFlag = false;
            _this.pharmacyFlag = false;
            _this._sharedService.showLoader = false;
        });
    }
    CenterLeftComponent.prototype.getDrugDetails = function (data) {
        var _this = this;
        if (data[0].dosage && data[0].dosage.length > 0) {
            data[0].dosage.forEach(function (obj) {
                var tempObj = {
                    "primarydisplay": ""
                };
                tempObj.primarydisplay = obj;
                _this.dosageData.push(tempObj);
            });
        }
        if (data[0].frequency && data[0].dosage.length > 0) {
            // data[0].frequency.forEach(obj => {
            //   let tempObj = {
            //     "primarydisplay": ""
            //   }
            //   tempObj.primarydisplay = obj
            //   this.frequencyData.push(tempObj);
            // });
            this.frequencyData = [{ "primarydisplay": "30 day supply" }, { "primarydisplay": "90 day supply" }];
        }
        if (data[0].package && data[0].package.length > 0) {
            data[0].package.forEach(function (obj) {
                var tempObj = {
                    "primarydisplay": ""
                };
                tempObj.primarydisplay = obj;
                _this.packageData.push(tempObj);
            });
        }
    };
    CenterLeftComponent.prototype.ngOnInit = function () {
        this.getWorkflowList();
    };
    CenterLeftComponent.prototype.ngOnDestroy = function () {
    };
    CenterLeftComponent.prototype.getWorkflowList = function () {
        this.workflowList = [
            {
                "workflowName": "OVATION PART D",
                "disabled": true,
                "value": 2
            },
            {
                "workflowName": "DRUG COST ESTIMATOR",
                "disabled": true,
                "value": 3
            }
        ];
    };
    CenterLeftComponent.prototype.workflowHandle = function (value) {
        if (value && value === 2) {
            this.ovaitionPartD(value);
        }
        else if (value && value === 3) {
            this.drugCostEsitmator(3);
        }
    };
    CenterLeftComponent.prototype.ovaitionPartD = function (value) {
        var _this = this;
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnR_Doc360",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Member Id": this._sharedService.memberId
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].OVATION_PART_D, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
            _this._sharedService.errorMsgData.push("Ovation request failed!");
        }, function () {
            _this._sharedService.showLoader = false;
            _this._sharedService.successMsgData.push("Ovation request submitted successfully!");
        });
    };
    CenterLeftComponent.prototype.drugCostEsitmator = function (value) {
        var _this = this;
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnR_DrugCost",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].GET_COUNTY, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
            _this._sharedService.errorMsgData.push(" Request Failed!");
        }, function () {
            if (response) {
                _this.showdrugcostestimator = true;
                _this._sharedService.getCountyData(response);
                _this.sendcounty(requestJson);
            }
            else {
                _this._sharedService.successMsgData.push("Unable to get county data estimator");
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterLeftComponent.prototype.sendcounty = function (request) {
        // let requestJson: any;
        // requestJson = {
        //   "Initial": false,
        //   "Data": {
        //     "RequestMetaData": {
        //       "Command": "MnR_DrugCost",
        //       "requestId": request.Data.RequestMetaData.requestId,
        //       "requestTime": request.Data.RequestMetaData.requestTime,
        //       "commandSeqId": 2
        //     },
        //     "RequestParams": {
        //       "index": this._sharedService.index
        //     }
        //   }
        // }
        // let response: any
        // this._rCallService.getCall(SERVICE_URL.SENT_COUNTY, requestJson).subscribe(
        //   (res: any) => {
        //     response = res;
        //   }, (error: any) => {
        //     this._sharedService.showLoader = false;
        //     this._sharedService.errorMsgData.push(" Request Failed!");
        //   }, () => {
        //     if (response) {
        //     } else {
        //       this._sharedService.showLoader = false;
        //     }
        //   });
    };
    CenterLeftComponent.prototype.searchHandle = function (searchObject) {
        var _this = this;
        this._sharedService.searchdisble = true;
        this._sharedService.resetData();
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRSearch",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "memberID": searchObject.memberId,
                    "medicareID": searchObject.medicareId,
                    "FirstName": searchObject.firstName,
                    "LastName": searchObject.lastName,
                    "DOB": this.date.transform(searchObject.dob, 'MM/dd/yyyy')
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].MNR_SEARCH, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addSearchResponse(response);
        });
    };
    CenterLeftComponent.prototype.oncostClick = function (event, num) {
        if (num == 1) {
            this.drugCostModel.county = event.primarydisplay;
            if (this.drugCostModel.drugname !== '') {
                this.costSearchFlag = false;
            }
            else {
                this.costSearchFlag = true;
            }
        }
        if (this.packageData.length > 0) {
            if (num == 2) {
                this.drugCostModel.dosage = event.primarydisplay;
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '' && this.drugCostModel.package !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
            else if (num == 3) {
                this.drugCostModel.frequency = event.primarydisplay;
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '' && this.drugCostModel.package !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
            else if (num == 4) {
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '' && this.drugCostModel.package !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
            else if (num == 5) {
                this.drugCostModel.package = event.primarydisplay;
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
        }
        else {
            if (num == 2) {
                this.drugCostModel.dosage = event.primarydisplay;
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
            else if (num == 3) {
                this.drugCostModel.frequency = event.primarydisplay;
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
            else if (num == 4) {
                if (this.drugCostModel.drugname !== '' && this.drugCostModel.dosage !== '' && this.drugCostModel.frequency !== '' && this.drugCostModel.quantity !== '') {
                    this.costSearchFlag = false;
                }
                else {
                    this.costSearchFlag = true;
                }
            }
        }
    };
    CenterLeftComponent.prototype.ondrugnameClick = function (event) {
        if (this.drugCostModel.drugname !== '') {
            if (this.drugCostModel.county !== '') {
                this.costSearchFlag = false;
            }
            else {
                this.costSearchFlag = true;
            }
        }
        else {
            this.costSearchFlag = true;
        }
    };
    CenterLeftComponent.prototype.onSearchClick = function () {
        var _this = this;
        if (this.drugDetails && this.drugDetails.length <= 0) {
            this.costSearchFlag = true;
            this._sharedService.showLoader = true;
            var requestJson = void 0;
            requestJson = {
                "Initial": true,
                "Data": {
                    "RequestMetaData": {
                        "Command": "MnR_DrugName",
                        "requestId": this._sharedService.getRequestId(),
                        "requestTime": this._sharedService.getRequestTime(),
                        "commandSeqId": 1
                    },
                    "RequestParams": {
                        "DrugName": this.drugCostModel.drugname,
                        "CountyName": this.drugCostModel.county
                    }
                }
            };
            var response_1;
            this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].DRUG_DETAILS, requestJson).subscribe(function (res) {
                response_1 = res;
            }, function (error) {
                _this._sharedService.showLoader = false;
                _this._sharedService.errorMsgData.push(" Request Failed!");
            }, function () {
                if (response_1) {
                    _this.showdrugcostestimator = true;
                    _this._sharedService.getDrugDetails(response_1);
                }
                else {
                    _this._sharedService.successMsgData.push("Unable to get drug data");
                    _this._sharedService.showLoader = false;
                }
            });
        }
        else {
            this._sharedService.showLoader = true;
            var requestJson = void 0;
            requestJson = {
                "Initial": true,
                "Data": {
                    "RequestMetaData": {
                        "Command": "MnR_Drug_Details",
                        "requestId": this._sharedService.getRequestId(),
                        "requestTime": this._sharedService.getRequestTime(),
                        "commandSeqId": 1
                    },
                    "RequestParams": {
                        "Dosage": this.drugCostModel.dosage,
                        "Frequency": this.drugCostModel.frequency,
                        "Quantity": this.drugCostModel.quantity,
                        "Package": this.drugCostModel.package
                    }
                }
            };
            var response_2;
            this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].PHARMACY_TABLE, requestJson).subscribe(function (res) {
                response_2 = res;
            }, function (error) {
                _this._sharedService.showLoader = false;
                _this._sharedService.errorMsgData.push(" Request Failed!");
            }, function () {
                if (response_2) {
                    _this.showdrugcostestimator = true;
                    _this._sharedService.getPharmacyDetails(response_2);
                }
                else {
                    _this._sharedService.successMsgData.push("Unable to get pharmacy data");
                    _this._sharedService.showLoader = false;
                }
            });
        }
    };
    CenterLeftComponent.prototype.onPharmacyClick = function (row) {
        var _this = this;
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnR_pharmacy_table",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Index": row.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].DRUG_COST_ESTIMATOR, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
            _this._sharedService.errorMsgData.push(" Request Failed!");
        }, function () {
            if (response) {
                _this._sharedService.getDrugCostDetails(response);
            }
            else {
                _this._sharedService.successMsgData.push("Unable to get cost data");
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterLeftComponent.prototype.onCloseClick = function () {
        this.countyData = [];
        this.dosageData = [];
        this.frequencyData = [];
        this.packageData = [];
        this.pharmacyData = [];
        this.costSearchFlag = true;
        this.drugDetails = [];
        this.copay = '';
        this.cost = '';
        this.costFlag = false;
        this.pharmacyFlag = false;
        this.countyFlag = true;
        this.drugFlag = false;
        this.drugCostModel = new DrugCostModel();
    };
    CenterLeftComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'center-left',
            template: __webpack_require__(/*! ./center-left.component.html */ "./src/app/layout-components/center-left/center-left.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["DomSanitizer"], src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_1__["RestCallService"], _services_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"]])
    ], CenterLeftComponent);
    return CenterLeftComponent;
}());

var DrugCostModel = /** @class */ (function () {
    function DrugCostModel() {
        this.county = '';
        this.drugname = '';
        this.dosage = '';
        this.frequency = '';
        this.quantity = '';
        this.package = '';
    }
    return DrugCostModel;
}());



/***/ }),

/***/ "./src/app/layout-components/center-left/searchbox/searchbox.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/layout-components/center-left/searchbox/searchbox.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-text-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'MEMBER ID'\" [(ngModel)]=\"searchModel.memberId\">\n</amexio-text-input>\n<amexio-row>\n      <amexio-column [size]=12> </amexio-column>\n   </amexio-row>\n<amexio-text-input  [field-label]=\"''\" name=\"name\" [place-holder]=\"'MEDICARE ID'\" [(ngModel)]=\"searchModel.medicareId\">\n</amexio-text-input>\n<amexio-row>\n   <amexio-column [size]=12> </amexio-column>\n</amexio-row>\n<amexio-text-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'FIRST NAME'\" [(ngModel)]=\"searchModel.firstName\">\n</amexio-text-input>\n<amexio-text-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'LAST NAME'\" [(ngModel)]=\"searchModel.lastName\">\n</amexio-text-input>\n\n<amexio-date-time-picker [place-holder]=\"'DOB'\" [date-picker]=\"true\" [(ngModel)]=\"searchModel.dob\">\n</amexio-date-time-picker>\n\n\n<amexio-layout-columns [fit]=\"true\" [border]=\"false\" [orientation]=\"'horizontal'\" [alignment]=\"'end'\">\n   <amexio-layout-item>\n      <amexio-button [disabled]=\"isSearchDisble\" [label]=\"'Search'\" [type]=\"'theme-color'\" [tooltip]=\"'large'\" [block]=\"false\"\n         (onClick)=\"onSearchClick()\">\n      </amexio-button>\n   </amexio-layout-item>\n</amexio-layout-columns>\n\n<!-- </div> -->"

/***/ }),

/***/ "./src/app/layout-components/center-left/searchbox/searchbox.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/layout-components/center-left/searchbox/searchbox.component.ts ***!
  \********************************************************************************/
/*! exports provided: SearchBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBoxComponent", function() { return SearchBoxComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _model_search_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../model/search.model */ "./src/app/model/search.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 3/6/19.
 */



var SearchBoxComponent = /** @class */ (function () {
    function SearchBoxComponent(_httpClient) {
        this._httpClient = _httpClient;
        this.showDropdown = false;
        this.dropDownItemList = [];
        this.searchId = '';
        this.searchType = 1;
        this.isSearchDisble = false;
        this.search = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.searchModel = new _model_search_model__WEBPACK_IMPORTED_MODULE_2__["SearchModel"]();
    }
    SearchBoxComponent.prototype.ngOnInit = function () {
    };
    SearchBoxComponent.prototype.onSearchClick = function () {
        this.search.emit(this.searchModel);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('isSearchDisble'),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "isSearchDisble", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], SearchBoxComponent.prototype, "search", void 0);
    SearchBoxComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'search-box',
            template: __webpack_require__(/*! ./searchbox.component.html */ "./src/app/layout-components/center-left/searchbox/searchbox.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], SearchBoxComponent);
    return SearchBoxComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.css":
/*!*****************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.css ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\n  border-collapse: collapse;\n}\n\ntable, td {\n  border: 1px solid gray;\n  padding: 5px;\n  text-align: left\n}\n\n"

/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [footer-align]=\"'center'\">\n  <amexio-body>\n    <amexio-tab-view [active-bg-color]=\"true\" [divide-header-equally]=\"true\" [closable]=\"false\" [body-height]=\"47\">\n      <amexio-tab title=\"MEMBER DETAILS\" [active]=\"true\">\n        <amexio-datagrid [enable-column-filter]=\"false\" [data]=\"memberDetails\" [page-size]=\"10\">\n          <amexio-data-table-column [width]=\"3\" [data-type]=\"'string'\" [hidden]=\"false\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n\n              <input style=\"width: 1.5em; height: 1.5em;\" type=\"radio\" name=\"check\" value=\"row.radioId\" (click)=\"getRadioSelectedRecord(row)\">\n\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"12\" [data-index]=\"'memberid'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'MEMBER ID'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"12\" [sort]=\"false\" [data-index]=\"'lastname'\" [data-type]=\"'string'\"\n            [hidden]=\"false\" [text]=\"'LAST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"12\" [data-index]=\"'firstname'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'FIRST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'dob'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'DOB'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"7\" [data-index]=\"'age'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'AGE'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'addressline1'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'ADDRESS'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"8\" [data-index]=\"'city'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'CITY'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"8\" [data-index]=\"'statecode'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'STATE'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'zipcode'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'ZIP'\">\n          </amexio-data-table-column>\n        </amexio-datagrid>\n        <br/>\n        <amexio-row *ngIf=\"memberDetails && memberDetails.length>0\">\n          <amexio-column>\n            <amexio-checkbox [disabled]=\"disbleChk\" [field-label]=\"'CALLER IS MEMBER'\" [(ngModel)]=\"check\"\n              (onSelection)=\"onCheckClick($event)\">\n            </amexio-checkbox>\n          </amexio-column>\n          <amexio-column>\n            <amexio-button [disabled]=\"disbleBTn\" (onClick)=\"getDemographicDetails()\" [label]=\"'Submit'\"\n              [type]=\"'theme-color'\">\n            </amexio-button>\n          </amexio-column>\n        </amexio-row>\n      </amexio-tab>\n      <amexio-tab title=\"CLAIMS\">\n        <amexio-datagrid class=\"claimgrid\" [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"claimsData\">\n          <amexio-data-table-column [width]=\"13\" [data-index]=\"'servicedate'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Service Dates'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"12\" [data-index]=\"'rxnumber'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Rx Number'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"15\" [data-index]=\"'drugname'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Drug Name'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Status'\">\n             <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n            <a style=\"color:red\">{{row.status}}</a>\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'group'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Group'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"30\" [data-index]=\"'claimmessages'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Claim Messages'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <table style=\"width:100%\">\n                <tr *ngFor=\"let item of row.claimmessages;let i = index;\">\n                  <td  (click)=\"onclaimhoverClick(row,i)\">{{item}}</td>\n                </tr>\n              </table>\n            </ng-template>\n          </amexio-data-table-column>\n             <amexio-data-table-column  [data-index]=\"'hover'\" [data-type]=\"'string'\" [hidden]=\"true\"\n            [text]=\"'Claim Messages'\">\n          </amexio-data-table-column>\n           <amexio-data-table-column [width]=\"20\" [data-index]=\"'action'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'Action'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <amexio-button (onClick)=\"onFormularyLookup(row)\" [label]=\"'FORMULARY LOOKUP'\" [type]=\"'theme-color'\">\n              </amexio-button>\n            </ng-template>\n          </amexio-data-table-column>\n        </amexio-datagrid>\n      </amexio-tab>\n      <amexio-tab title=\"PLAN DETAILS\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet\n        aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus\n        tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"SERVICE REQUESTS\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet\n        aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus\n        tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"INTERACTION HISTORY\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet\n        aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus\n        tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"MARKETING HISTORY\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet\n        aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus\n        tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"DETAILS TAB\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet\n        aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus\n        tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n    </amexio-tab-view>\n    <div  style=\"padding: 10px 10px 0px 10px; background-color: var(--appBackground);\">\n      <amexio-row>\n        <amexio-column [size]=12>\n          <amexio-checkbox-group [http-url]=\"'assets/querycheckbox.json'\" [http-method]=\"'get'\" [data-reader]=\"'data'\"\n            [display-field]=\"'name'\" [horizontal]=\"true\" [value-field]=\"'checked'\">\n          </amexio-checkbox-group>\n        </amexio-column>\n      </amexio-row>\n      <amexio-layout-columns [border]=\"false\" [fit]=\"true\" [orientation]=\"'horizontal'\" [alignment]=\"'space-between'\">\n        <amexio-layout-item style=\"width:95%\">\n          <amexio-text-input name=\"name\" icon-feedback=\"true\">\n          </amexio-text-input>\n        </amexio-layout-item>\n        <amexio-layout-item>\n          <amexio-button [label]=\"'Submit'\" [type]=\"'theme-color'\">\n          </amexio-button>\n        </amexio-layout-item>\n      </amexio-layout-columns>\n    </div>\n  </amexio-body>\n</amexio-card>\n<alert-window></alert-window>\n<formulary-lookup></formulary-lookup>\n <amexio-window-ce [(show)]=\"showRelativePanel1\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"50%\">\n  <amexio-body-ce>\n     <div [innerHTML]=\"hoverData\"></div>\n  </amexio-body-ce>\n</amexio-window-ce>"

/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.ts ***!
  \****************************************************************************/
/*! exports provided: CenterMiddleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CenterMiddleComponent", function() { return CenterMiddleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/rest.call.service */ "./src/app/services/rest.call.service.ts");
/* harmony import */ var src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/constants/service.constant */ "./src/app/constants/service.constant.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CenterMiddleComponent = /** @class */ (function () {
    function CenterMiddleComponent(_rCallService, _sharedService) {
        var _this = this;
        this._rCallService = _rCallService;
        this._sharedService = _sharedService;
        this.memberDetails = [];
        this.claimsData = [];
        this.disbleBTn = true;
        this.disbleChk = true;
        this.check = false;
        this.isRadioCheck = false;
        this.showRelativePanel1 = false;
        this._sharedService.searchResponse.subscribe(function (data) {
            _this.memberDetails = Object.assign([], data);
            if (_this.memberDetails) {
                _this._sharedService.showAlert = false;
                var max_1 = 10;
                _this.memberDetails.forEach(function (object, index) {
                    object['radioId'] = Math.floor(Math.random() * max_1 + 1);
                    object['index'] = index;
                });
            }
            _this._sharedService.searchdisble = false;
            _this.check = false;
            _this.disbleChk = true;
            _this.disbleBTn = true;
            _this._sharedService.showLoader = false;
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.memberDetails = [];
            _this.claimsData = [];
            _this._sharedService.showLoader = false;
        });
        this._sharedService.claimsData.subscribe(function (data) {
            if (data != null) {
                data.forEach(function (obj) {
                    if (obj["claimmessages"] || obj["hover"]) {
                        obj["claimmessages"] = obj.claimmessages.split("+");
                        obj["claimmessages"] = obj["claimmessages"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["hover"] = obj.hover.split("+");
                        obj["hover"] = obj["hover"].filter(function (msg) { return msg.trim().length > 0; });
                    }
                });
                _this.claimsData = Object.assign([], data);
            }
            _this._sharedService.showLoader = false;
        });
    }
    CenterMiddleComponent.prototype.ngOnInit = function () {
    };
    CenterMiddleComponent.prototype.onCheckClick = function (event) {
        if (event) {
            this.disbleBTn = false;
        }
        else {
            this.disbleBTn = true;
        }
    };
    CenterMiddleComponent.prototype.getDemographicDetails = function () {
        this.getDemographic();
    };
    CenterMiddleComponent.prototype.getDemographic = function () {
        var _this = this;
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].DEMOGRAPHIC_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addDemographic(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getMemberDetails(requestJson);
            }
            else {
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterMiddleComponent.prototype.getMemberDetails = function (requestdata) {
        var _this = this;
        var requestJson;
        requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": requestdata.Data.RequestMetaData.requestId,
                    "requestTime": requestdata.Data.RequestMetaData.requestTime,
                    "commandSeqId": 2
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].MEMEBER_DETAILS_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addSelectedMember(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getPlanDetails(requestJson);
            }
            else {
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterMiddleComponent.prototype.getPlanDetails = function (requestdata) {
        var _this = this;
        var requestJson;
        requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": requestdata.Data.RequestMetaData.requestId,
                    "requestTime": requestdata.Data.RequestMetaData.requestTime,
                    "commandSeqId": 3
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].PLAN_DETAILS_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addPlanDetails(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getBillingSummary(requestJson);
            }
            else {
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterMiddleComponent.prototype.getBillingSummary = function (requestdata) {
        // let requestJson: any;
        // requestJson = {
        //   "Initial": false,
        //   "Data": {
        //     "RequestMetaData": {
        //       "Command": "MnRCallerIsMember",
        //       "requestId": requestdata.Data.RequestMetaData.requestId,
        //       "requestTime": requestdata.Data.RequestMetaData.requestTime,
        //       "commandSeqId": 4
        //     },
        //     "RequestParams": {
        //       "Caller Is The Member": this.check,
        //       "Index": this._sharedService.index
        //     }
        //   }
        // }
        // let response: any;
        // this._rCallService.getCall(SERVICE_URL.BILLING_SUMMARY_DETAILS_DATA, requestJson).subscribe(
        //   (res: any) => {
        //     response = res;
        //   }, (error: any) => {
        //     this._sharedService.showLoader = false;
        //   }, () => {
        //     this._sharedService.addBillingSummary(response);
        //     this.getCoverageStage(requestJson);
        //   });
        this.getCoverageStage(requestdata);
    };
    CenterMiddleComponent.prototype.getCoverageStage = function (requestdata) {
        var _this = this;
        var requestJson;
        requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": requestdata.Data.RequestMetaData.requestId,
                    "requestTime": requestdata.Data.RequestMetaData.requestTime,
                    "commandSeqId": 4
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].COVERAGE_DETAILS, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addCoverageStag(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getRejectedClaimData(requestJson);
            }
            else {
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterMiddleComponent.prototype.getRejectedClaimData = function (requsetjson) {
        var _this = this;
        var requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": requsetjson.Data.RequestMetaData.requestId,
                    "requestTime": requsetjson.Data.RequestMetaData.requestTime,
                    "commandSeqId": 5
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].REJECTED_CLIAMS, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.getRejectedClaims(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getClaims(requestJson);
            }
            else {
                _this._sharedService.showLoader = false;
            }
        });
    };
    CenterMiddleComponent.prototype.getClaims = function (requestdata) {
        var _this = this;
        var requestJson;
        requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnRCallerIsMember",
                    "requestId": requestdata.Data.RequestMetaData.requestId,
                    "requestTime": requestdata.Data.RequestMetaData.requestTime,
                    "commandSeqId": 6
                },
                "RequestParams": {
                    "Caller Is The Member": this.check,
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].MNR_CLAIMS_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.setClaimsData(response);
        });
    };
    CenterMiddleComponent.prototype.getRadioSelectedRecord = function (row) {
        this._sharedService.index = row.index;
        this.disbleChk = false;
        this._sharedService.memberId = row.memberid;
    };
    CenterMiddleComponent.prototype.onFormularyLookup = function (row) {
        var _this = this;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "MnR_RxWeb",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Drug Name": row.drugname
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].FORMULARY_LOOKUP, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.getFormularyLookup(response);
        });
    };
    CenterMiddleComponent.prototype.onclaimhoverClick = function (row, index) {
        this.hoverData = [];
        this.hoverData = row.hover[index];
        this.showRelativePanel1 = true;
    };
    CenterMiddleComponent.prototype.onLeaveRelativePanel = function () {
        this.hoverData = [];
        this.showRelativePanel1 = !this.showRelativePanel1;
    };
    CenterMiddleComponent.prototype.onCloseRelativePanel = function (event) {
        this.showRelativePanel1 = event.showRelativePanel1;
    };
    CenterMiddleComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'center-middle',
            template: __webpack_require__(/*! ./center-middle.component.html */ "./src/app/layout-components/center-middle/center-middle.component.html"),
            styles: [__webpack_require__(/*! ./center-middle.component.css */ "./src/app/layout-components/center-middle/center-middle.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_2__["RestCallService"], src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], CenterMiddleComponent);
    return CenterMiddleComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/comapny-logo/company.logo.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/comapny-logo/company.logo.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"33\">\n    <amexio-body>\n            <amexio-layout-columns [orientation]=\"'vertical'\" [border]=\"false\" alignment=\"space-between\">\n  <amexio-layout-item [padding]=\"'0px'\" [fit]=\"true\">\n    <amexio-layout-columns [orientation]=\"'horizontal'\" [fit]=\"true\" [border]=\"false\" alignment=\"center\">\n      <amexio-layout-item [padding]=\"'0px'\">\n        <amexio-image   [path]=\"'assets/images/optum.png'\" [filter]=\"'normal'\">\n        </amexio-image>\n      </amexio-layout-item>\n    </amexio-layout-columns>\n  </amexio-layout-item><br>\n \n</amexio-layout-columns>\n    </amexio-body>\n </amexio-card>"

/***/ }),

/***/ "./src/app/layout-components/comapny-logo/company.logo.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/comapny-logo/company.logo.component.ts ***!
  \**************************************************************************/
/*! exports provided: CompanyLogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyLogoComponent", function() { return CompanyLogoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 3/6/19.
 */


var CompanyLogoComponent = /** @class */ (function () {
    function CompanyLogoComponent(_httpClient) {
        this._httpClient = _httpClient;
    }
    CompanyLogoComponent.prototype.ngOnInit = function () {
    };
    CompanyLogoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'company-logo',
            template: __webpack_require__(/*! ./company.logo.component.html */ "./src/app/layout-components/comapny-logo/company.logo.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], CompanyLogoComponent);
    return CompanyLogoComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/customer-demographic/customer-demographic.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/layout-components/customer-demographic/customer-demographic.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\"  [body-height]=\"33\">\n  <amexio-body>\n    <b>MEMBER DETAILS</b>\n    <amexio-property-grid [key-value-data]=\"customerKeyValuedata\">\n    </amexio-property-grid>\n  </amexio-body>\n</amexio-card>\n\n"

/***/ }),

/***/ "./src/app/layout-components/customer-demographic/customer-demographic.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/layout-components/customer-demographic/customer-demographic.component.ts ***!
  \******************************************************************************************/
/*! exports provided: CustomerDemoGraphicComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDemoGraphicComponent", function() { return CustomerDemoGraphicComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../model/propertygrid.model */ "./src/app/model/propertygrid.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 3/6/19.
 */



var CustomerDemoGraphicComponent = /** @class */ (function () {
    function CustomerDemoGraphicComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.customerKeyValuedata = [];
        this.memberData = [];
        this.demographic = [];
        this._sharedService.demographicData.subscribe(function (data) {
            if (data != null) {
                _this.demographic = data[0];
                _this.updatePropertyStructure();
            }
        });
        this._sharedService.selectedMember.subscribe(function (data) {
            if (data != null) {
                _this.memberData = data[0];
                _this.updateMemberPropertyStructure();
            }
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.createPropertyStructure();
        });
        this._sharedService.showLoader = false;
    }
    CustomerDemoGraphicComponent.prototype.ngOnInit = function () {
        this.createPropertyStructure();
    };
    CustomerDemoGraphicComponent.prototype.ngOnDestroy = function () {
    };
    CustomerDemoGraphicComponent.prototype.createPropertyStructure = function () {
        this.customerKeyValuedata = [];
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Full Name', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Status', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Gender', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('DOB', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Age', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Address', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Medicare claim No.', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Member Start Date', ''));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Source System', ''));
    };
    CustomerDemoGraphicComponent.prototype.updatePropertyStructure = function () {
        this.customerKeyValuedata = [];
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Full Name', this.demographic.fullname));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Status', this.demographic.status));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Gender', this.demographic.gender));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('DOB', this.demographic.dob));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Age', this.demographic.age));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Address', this.demographic.address));
    };
    CustomerDemoGraphicComponent.prototype.updateMemberPropertyStructure = function () {
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Medicare claim No.', this.memberData.medicareclaimno));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Member Start Date', this.memberData.memberstartdate));
        this.customerKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Source System', this.memberData.sourcesystem));
    };
    CustomerDemoGraphicComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customer-demo-graphic',
            template: __webpack_require__(/*! ./customer-demographic.component.html */ "./src/app/layout-components/customer-demographic/customer-demographic.component.html")
        }),
        __metadata("design:paramtypes", [src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], CustomerDemoGraphicComponent);
    return CustomerDemoGraphicComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/layout-components/formulary-lookup/formulary-lookup.component.css ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.html":
/*!************************************************************************************!*\
  !*** ./src/app/layout-components/formulary-lookup/formulary-lookup.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-window-ce [(show)]=\"_sharedService.showlookup\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"80%\"\n    align=\"start\">\n    <amexio-header-ce align=\"left\" vertical-align=\"top\">\n        <amexio-layout-columns alignment=\"start\" [orientation]=\"'horizontal'\" [border]=\"false\">\n        <amexio-layout-item>      \n          <amexio-label size=\"medium-bold\">FORMULARY LOOKUP</amexio-label>\n            </amexio-layout-item>\n        </amexio-layout-columns>\n    </amexio-header-ce>\n    <amexio-body-ce >\n   CLAIM #: 123808730-01\n   <iframe style=\"width: 100%; height: 600px;\" [src]=\"urlSafe\"\n          frameborder=\"1\" allowfullscren=\"allowfullscren\"></iframe>\n    </amexio-body-ce>\n</amexio-window-ce>\n"

/***/ }),

/***/ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/layout-components/formulary-lookup/formulary-lookup.component.ts ***!
  \**********************************************************************************/
/*! exports provided: FormularyLookupComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormularyLookupComponent", function() { return FormularyLookupComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FormularyLookupComponent = /** @class */ (function () {
    function FormularyLookupComponent(_sharedService, sanitizer) {
        var _this = this;
        this._sharedService = _sharedService;
        this.sanitizer = sanitizer;
        this._sharedService.formularyLookup.subscribe(function (data) {
            if (data) {
                setTimeout(function () {
                    _this.urlSafe = _this.sanitizer.bypassSecurityTrustResourceUrl(data[0].url);
                    _this._sharedService.showlookup = true;
                }, 100);
            }
            _this._sharedService.showLoader = false;
        });
    }
    FormularyLookupComponent.prototype.ngOnInit = function () {
    };
    FormularyLookupComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'formulary-lookup',
            template: __webpack_require__(/*! ./formulary-lookup.component.html */ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.html"),
            styles: [__webpack_require__(/*! ./formulary-lookup.component.css */ "./src/app/layout-components/formulary-lookup/formulary-lookup.component.css")]
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]])
    ], FormularyLookupComponent);
    return FormularyLookupComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/product-details/product-details.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/layout-components/product-details/product-details.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-row>\n    <amexio-column [size]=\"6\">\n<amexio-card [header]=\"false\" [footer]=\"false\"  [body-height]=\"34\">\n  <amexio-body>\n    <b>PLAN DETAILS</b>\n    <amexio-property-grid [key-value-data]=\"productKeyValuedata\">\n    </amexio-property-grid>\n    <!-- <b>Billing Summary</b>\n    <amexio-property-grid [key-value-data]=\"billingKeyValuedata\">\n    </amexio-property-grid> -->\n  </amexio-body>\n</amexio-card>\n   </amexio-column>\n    <amexio-column [size]=\"6\">\n<amexio-card [header]=\"false\" [footer]=\"false\"  [body-height]=\"34\">\n  <amexio-body>\n    <b>COVERAGE STAGE</b>\n    <amexio-property-grid [key-value-data]=\"coverageKeyValuedata\">\n    </amexio-property-grid>\n  </amexio-body>\n</amexio-card>\n    </amexio-column>\n</amexio-row>\n\n"

/***/ }),

/***/ "./src/app/layout-components/product-details/product-details.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/layout-components/product-details/product-details.component.ts ***!
  \********************************************************************************/
/*! exports provided: ProductDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsComponent", function() { return ProductDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../model/propertygrid.model */ "./src/app/model/propertygrid.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ProductDetailsComponent = /** @class */ (function () {
    function ProductDetailsComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.productData = [];
        this.billingData = [];
        this.coverageData = [];
        this._sharedService.productsData.subscribe(function (data) {
            if (data != null) {
                _this.productData = data[0];
                _this.updatePropertyStructure();
            }
        });
        this._sharedService.billingSummaryData.subscribe(function (data) {
            if (data != null) {
                _this.billingData = data[0];
                _this.updateBillingSummary();
            }
        });
        this._sharedService.coverageStags.subscribe(function (data) {
            if (data != null) {
                _this.coverageData = data[0];
                _this.updateCoverageStructure();
            }
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.createPropertyStructure();
            _this._sharedService.showLoader = false;
        });
    }
    ProductDetailsComponent.prototype.ngOnInit = function () {
        this.createPropertyStructure();
    };
    ProductDetailsComponent.prototype.ngOnDestroy = function () {
    };
    ProductDetailsComponent.prototype.createPropertyStructure = function () {
        this.productKeyValuedata = [];
        this.coverageKeyValuedata = [];
        this.billingKeyValuedata = [];
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Name', ''));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Status', ''));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Start Date', ''));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Type', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Next billing Cycle Date', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Unpaid Balance/COA:(+$)Unpaid(-$) COA', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Estimated Annual  Premium Remaining', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('# of past dure Bill Date', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Bankrupty Petition Date', ''));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Payment Method', ''));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Your Initial Coverage Limit', ''));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Copayments and Coinsurance paid by you', ''));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Your plan has Paid', ''));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Total paid by you and your plan', ''));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Amount remaining before coverage gap', ''));
    };
    ProductDetailsComponent.prototype.updatePropertyStructure = function () {
        this.productKeyValuedata = [];
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Name', this.productData.planname));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Status', this.productData.planstatus));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Start Date', this.productData.planstartdate));
        this.productKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Type', this.productData.plantype));
    };
    ProductDetailsComponent.prototype.updateBillingSummary = function () {
        this.billingKeyValuedata = [];
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Next billing Cycle Date', this.billingData.nextbillingcycledate));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Unpaid Balance/COA:(+$)Unpaid(-$) COA', this.billingData.unpaidbalancecoa));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Estimated Annual  Premium Remaining', this.billingData.estimatedannualpremiumremaining));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('# Of Past Due Bill Date', this.billingData.ofpastduebilldate));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Bankrupty Petition Date', this.billingData.bankruptypetitiondate));
        this.billingKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Payment Method', this.billingData.paymentmethod));
    };
    ProductDetailsComponent.prototype.updateCoverageStructure = function () {
        this.coverageKeyValuedata = [];
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Your Initial Coverage Limit', this.coverageData.yourinitialcoveragelimit));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Copayments and Coinsurance paid by you', this.coverageData.copaymentsandcoinsurancepaidbyyou));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Your plan has Paid', this.coverageData.yourplanhaspaid));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Total paid by you and your plan', this.coverageData.totalpaidbyyouandyourplan));
        this.coverageKeyValuedata.push(new _model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Amount remaining before coverage gap', this.coverageData.amountremainingbeforecoveragegap));
    };
    ProductDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'product',
            template: __webpack_require__(/*! ./product-details.component.html */ "./src/app/layout-components/product-details/product-details.component.html")
        }),
        __metadata("design:paramtypes", [src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], ProductDetailsComponent);
    return ProductDetailsComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/top-right/top-right.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/layout-components/top-right/top-right.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"34\">\n  <amexio-body>\n        <div style=\"text-align: center;\">\n            <b>{{date | date : 'short'}}</b> &nbsp;\n        <amexio-button [label]=\"'Logout'\" [type]=\"'transparent'\"\n        [tooltip]=\"'Logout'\" [icon]=\"'fa fa-sign-out'\" (onClick)=\"logoutClick()\">\n      </amexio-button>\n    </div>\n    <br />\n        <br />\n        <amexio-row>\n          <amexio-column size=\"6\" style=\"text-align: center;\">\n            <amexio-dashboard-gauge [data]=\"guagedata\" [red-color-from]=\"90\" [red-color-to]=\"100\" [yellow-color-from]=\"75\"\n              [yellow-color-to]=\"90\" [scale-value]=\"5\">\n            </amexio-dashboard-gauge>\n            <b>CSAT 70/100%</b>\n          </amexio-column>\n          <amexio-column size=\"6\" style=\"text-align: center;\" *ngIf=\"showguage\">\n            <amexio-dashboard-gauge [data]=\"guagedataone\" [red-color-from]=\"90\" [red-color-to]=\"100\"\n              [yellow-color-from]=\"75\" [yellow-color-to]=\"90\" [scale-value]=\"5\">\n            </amexio-dashboard-gauge>\n            <b>AHT SLA 200</b>\n          </amexio-column>\n        </amexio-row>\n        \n        <amexio-row>\n          <amexio-column size=\"12\">\n            <div style=\"display: inline-flex; justify-content: center; width:100%;cursor:pointer;\">\n              <i *ngIf=\"_sharedService.showAlert\" class=\"fa fa-exclamation-triangle fa-2x\"  style=\"color: var(--themeSecondaryColor);\" (click)=\"onAlertClick()\"></i>\n            </div>\n          </amexio-column>\n        </amexio-row>\n  </amexio-body>\n</amexio-card>\n\n<amexio-dialogue [show-dialogue]=\"confirmdialogue\" [title]=\"'Confirm'\" [message]=\"'Are you sure you want to logout?'\"\n  [message-type]=\"'confirm'\" [type]=\"'confirm'\" (actionStatus)=\"checkStatus($event)\"\n  (close)=\"confirmdialogue = !confirmdialogue\">\n</amexio-dialogue>"

/***/ }),

/***/ "./src/app/layout-components/top-right/top-right.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/layout-components/top-right/top-right.component.ts ***!
  \********************************************************************/
/*! exports provided: TopRightComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopRightComponent", function() { return TopRightComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 4/6/19.
 */



var TopRightComponent = /** @class */ (function () {
    function TopRightComponent(_httpClient, _sharedService) {
        this._httpClient = _httpClient;
        this._sharedService = _sharedService;
        this.uiLoadingCount = [];
        this.confirmdialogue = false;
        this.showguage = false;
        this.guagedata = [
            ['Label', 'Value'],
            ['CSAT', 80]
        ];
        this.guagedataone = [
            ['Label', 'Value'],
            ['AHT-SLA', 68]
        ];
    }
    TopRightComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.showguage = true;
            _this.startTimer();
        }, 500);
    };
    TopRightComponent.prototype.startTimer = function () {
        this.date = new Date();
    };
    TopRightComponent.prototype.onAlertClick = function () {
        this._sharedService.showAlertWindow = true;
    };
    TopRightComponent.prototype.logoutClick = function () {
        this.confirmdialogue = !this.confirmdialogue;
    };
    TopRightComponent.prototype.checkStatus = function (data) {
        var LogoutMsg;
        if (data === 'ok') {
            window.open('http://35.231.95.65:8080/index.html', "_self");
        }
    };
    TopRightComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'top-right',
            template: __webpack_require__(/*! ./top-right.component.html */ "./src/app/layout-components/top-right/top-right.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _services_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"]])
    ], TopRightComponent);
    return TopRightComponent;
}());



/***/ }),

/***/ "./src/app/model/propertygrid.model.ts":
/*!*********************************************!*\
  !*** ./src/app/model/propertygrid.model.ts ***!
  \*********************************************/
/*! exports provided: PropertyModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertyModel", function() { return PropertyModel; });
var PropertyModel = /** @class */ (function () {
    function PropertyModel(_fieldName, _fieldValue) {
        this.fieldName = _fieldName;
        this.fieldValue = _fieldValue;
    }
    return PropertyModel;
}());



/***/ }),

/***/ "./src/app/model/search.model.ts":
/*!***************************************!*\
  !*** ./src/app/model/search.model.ts ***!
  \***************************************/
/*! exports provided: SearchModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModel", function() { return SearchModel; });
var SearchModel = /** @class */ (function () {
    function SearchModel() {
        this.memberId = '';
        this.medicareId = '';
        this.firstName = '';
        this.lastName = '';
        this.dob = '';
    }
    return SearchModel;
}());



/***/ }),

/***/ "./src/app/services/rest.call.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/rest.call.service.ts ***!
  \***********************************************/
/*! exports provided: RestCallService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestCallService", function() { return RestCallService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RestCallService = /** @class */ (function () {
    function RestCallService(http) {
        this.http = http;
    }
    RestCallService.prototype.postCall = function (serviceUrl, methodType, requestJson) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().append('Content-Type', 'application/x-www-form-urlencoded');
        if (methodType === 'post') {
            return this.http.post(serviceUrl, requestJson, { headers: headers });
        }
    };
    RestCallService.prototype.getCall = function (serviceUrl, requestJson) {
        console.log(JSON.stringify(requestJson.Data));
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().append('Content-Type', 'application/x-www-form-urlencoded');
        var newsrurl = serviceUrl + "?initial=" + requestJson.Initial + "&data=" + encodeURIComponent(JSON.stringify(requestJson.Data));
        //const newsrurl = serviceUrl ;
        console.log(" URL Payload : " + newsrurl);
        return this.http.post(newsrurl, { headers: headers });
    };
    RestCallService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], RestCallService);
    return RestCallService;
}());



/***/ }),

/***/ "./src/app/services/shared.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/shared.service.ts ***!
  \********************************************/
/*! exports provided: SharedService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedService", function() { return SharedService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SharedService = /** @class */ (function () {
    function SharedService() {
        this.showLoader = false;
        this.showAlert = false;
        this.errorMsgData = [];
        this.successMsgData = [];
        this.showAlertWindow = false;
        this.showlookup = false;
        this.searchdisble = false;
        this.searchResponse = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.selectedMember = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.claimsData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.selectMember = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false);
        this.productsData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.billingSummaryData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.coverageStags = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.demographicData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.rejectedClaimData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.formularyLookup = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.resetDetails = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.countyData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.countyValue = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.drugDetails = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.pharmacyDetails = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.drugCost = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
    }
    SharedService.prototype.addSearchResponse = function (response) {
        if (response.Data.ResponseStatus.success || response.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(response));
            var cd = this.covertData(response);
            this.searchResponse.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(response.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.resetData = function () {
        var data = [];
        this.resetDetails.next(data);
    };
    SharedService.prototype.addSelectedMember = function (memberDetails) {
        if (memberDetails.Data.ResponseStatus.success || memberDetails.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(memberDetails));
            var cd = this.covertData(memberDetails);
            this.selectedMember.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(memberDetails.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.updateSelectMemberFlag = function (value) {
        this.selectMember.next(value);
    };
    SharedService.prototype.addDemographic = function (demographic) {
        if (demographic.Data.ResponseStatus.success || demographic.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(demographic));
            var cd = this.covertData(demographic);
            this.demographicData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(demographic.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.setClaimsData = function (claims) {
        if (claims.Data.ResponseStatus.success || claims.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(claims));
            var cd = this.covertData(claims);
            this.claimsData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(claims.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.addPlanDetails = function (planDetails) {
        if (planDetails.Data.ResponseStatus.success || planDetails.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(planDetails));
            var cd = this.covertData(planDetails);
            this.productsData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(planDetails.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.addBillingSummary = function (summaryDetails) {
        if (summaryDetails.Data.ResponseStatus.success || summaryDetails.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(summaryDetails));
            var cd = this.covertData(summaryDetails);
            this.billingSummaryData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(summaryDetails.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.addCoverageStag = function (coverageStags) {
        if (coverageStags.Data.ResponseStatus.success || coverageStags.Data.ResponseStatus.Success) {
            console.log(JSON.stringify(coverageStags));
            var cd = this.covertData(coverageStags);
            this.coverageStags.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(coverageStags.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getRejectedClaims = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.rejectedClaimData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getFormularyLookup = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.formularyLookup.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getCountyData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.countyData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.sendCountyData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.countyValue.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getDrugDetails = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.drugDetails.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getPharmacyDetails = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.pharmacyDetails.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getDrugCostDetails = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.drugCost.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    /* Convert Key into lowercase */
    SharedService.prototype.covertData = function (response) {
        var _this = this;
        return Object.keys(response)
            .reduce(function (destination, key) {
            destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()] = response[key];
            var data = destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()];
            if (typeof (data) === 'object' && data.length !== undefined && data.length > 0) {
                data.forEach(function (obj, index) {
                    if (typeof (obj) === 'object') {
                        data[index] = _this.covertData(obj);
                    }
                });
            }
            else if (data && (data.length == undefined)) {
                destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()] = _this.covertData(data);
            }
            return destination;
        }, {});
    };
    SharedService.prototype.getRequestId = function () {
        return new Date().getTime() + Math.floor(Math.random() * 100 + 1);
    };
    SharedService.prototype.getRequestTime = function () {
        return new Date().getTime();
    };
    SharedService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], SharedService);
    return SharedService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/ashwini/gic-rina-poc/OPTUM-POC/latest/gic-optum/MnR/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map