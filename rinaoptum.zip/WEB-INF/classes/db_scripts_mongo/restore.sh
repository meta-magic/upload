#!/bin/bash
echo " enter db" 
read db
echo " enter username"
read user
echo " enter password  "
read pass

echo " enter path of backup"

read path
 
mongorestore --host localhost --port 27017  --db $db --username $user --password $pass  $path
