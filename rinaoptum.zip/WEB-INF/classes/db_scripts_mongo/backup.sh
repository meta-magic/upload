#!/bin/bash
echo " enter db" 
read db
echo " enter username"
read user
echo " enter password  "
read pass

echo " enter path to backup"

read path
mongodump --host localhost --port 27017 --db $db --username $user --password $pass --out $path
