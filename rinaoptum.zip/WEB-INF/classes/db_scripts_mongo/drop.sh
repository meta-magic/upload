
# This script will drop the database setup

FILE_PATH=$(pwd)

DATABASE_HOST="localhost"
DATABASE_PORT="27017"
DATABASE_NAME="rinaoptum"

CONNECTION_URL=$DATABASE_HOST:$DATABASE_PORT/$DATABASE_NAME

mongo $CONNECTION_URL $FILE_PATH/script/drop-script.js
