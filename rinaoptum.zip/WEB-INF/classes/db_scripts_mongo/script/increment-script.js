var DATABASE_USER = "rinaoptum"
var DATABASE_USER_PASSWORD = "rinaoptum@123"

var authStatus = db.auth(DATABASE_USER, DATABASE_USER_PASSWORD);
if (authStatus != 1) {
	exit;
}

print("Incremental script setup started.");

db.invalid_field_reasoning.drop()
db.createCollection("invalid_field_reasoning")

print("Incremental script completed.");

