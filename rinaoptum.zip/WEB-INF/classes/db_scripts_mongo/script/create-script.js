//add super user here
var ADMIN_USER = "magicuser"
//add super users password here	
var ADMIN_PASSWORD = "abc123"
	
var DATABASE_NAME = "rinaoptum"
var DATABASE_USER = "rinaoptum"
var DATABASE_USER_PASSWORD = "rinaoptum@123"
var DATABASE_USER_ROLE = "dbOwner"

print("Database setup started.");

print("Authenticating admin user");
var authStatus = db.auth(ADMIN_USER, ADMIN_PASSWORD);
authStatus == 1 ? print("Authentication successful") : exit
	
print("Database " + DATABASE_NAME + " creation process started.");
db = db.getSiblingDB(DATABASE_NAME);
print("Database " + DATABASE_NAME + " creation process completed successfully.");

print("User account creation process started.");
db.createUser({
	user : DATABASE_USER,
	pwd : DATABASE_USER_PASSWORD,
	roles : [ {
		role : DATABASE_USER_ROLE,
		db : DATABASE_NAME
	} ]
});
print("User account creation process completed successfully.");

print("Database setup completed");
print("Note: Please add data to the collections by running load.sh");
