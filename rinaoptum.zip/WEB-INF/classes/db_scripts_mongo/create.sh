
# This script will create the database setup
#

FILE_PATH=$(pwd)

DATABASE_HOST="localhost"
DATABASE_PORT="27017"
ADMIN_DATABASE="admin"
CONNECTION_URL=$DATABASE_HOST:$DATABASE_PORT/$ADMIN_DATABASE

mongo $CONNECTION_URL $FILE_PATH/script/create-script.js
