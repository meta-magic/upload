#
# This script will load the data in associated database

FILE_PATH=$(pwd)

DATABASE_HOST="localhost"
DATABASE_PORT="27017"
DATABASE_NAME="rinaoptum"
DATABASE_USER="rinaoptum"
DATABASE_USER_PASSWORD="rinaoptum@123"
CONNECTION_URL=$DATABASE_HOST:$DATABASE_PORT

echo "Load database process started."

echo Loading data.

mongoimport --host $CONNECTION_URL --username $DATABASE_USER --password $DATABASE_USER_PASSWORD --db $DATABASE_NAME --collection login_details --jsonArray --file $FILE_PATH/data/login_details.json

mongoimport --host $CONNECTION_URL --username $DATABASE_USER --password $DATABASE_USER_PASSWORD --db $DATABASE_NAME --collection user_details --jsonArray --file $FILE_PATH/data/user_details.json

echo Loading data successfully done.
echo Load database process successfully completed.
