(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"padding: 5px;\">\n  <amexio-layout-grid [layout]=\"gridcss\">\n    <amexio-grid-item [min-content]=\"true\" [name]=\"'rinatenantbranding'\">\n      <company-logo></company-logo>\n    </amexio-grid-item>\n    <amexio-grid-item [name]=\"'rinacustomerdemographics'\">\n      <customer-demo-graphic></customer-demo-graphic>\n    </amexio-grid-item>\n    <amexio-grid-item [name]=\"'rinaproducts'\" style=\"margin: -5px 0px;\">\n      <product-detail style=\"display: block; margin: 0px -5px -5px -5px;\"></product-detail>\n\n    </amexio-grid-item>\n    <amexio-grid-item [min-content]=\"true\" [name]=\"'rinaworkflows'\">\n      <center-left></center-left>\n    </amexio-grid-item>\n    <amexio-grid-item [name]=\"'rinacentertablayout'\">\n      <center-middle></center-middle>\n    </amexio-grid-item>\n    <amexio-grid-item [hc-enabled]=\"false\" [hc-direction]=\"'right'\" [name]=\"'ringleftblock'\">\n      <top-right></top-right>\n      <!-- <center-right></center-right>   -->\n    </amexio-grid-item>\n  </amexio-layout-grid>\n</div>\n\n<amexio-spinner [show]=\"_sharedService.showLoader\" [type]=\"'rectanglebounce'\" [vertical-position]=\"'top'\"\n  [horizontal-position]=\"'center'\" [color]=\"'yellow'\">\n</amexio-spinner>\n<amexio-notification [data]=\"_sharedService.errorMsgData\" [vertical-position]=\"'top'\" [horizontal-position]=\"'right'\"\n  [close-on-escape]=\"true\" [background-color]=\"'red'\" [auto-dismiss-msg]=\"true\" [auto-dismiss-msg-interval]=\"8000\">\n</amexio-notification>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! amexio-ng-extensions */ "./node_modules/amexio-ng-extensions/amexio-ng-extensions.es5.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */



var AppComponent = /** @class */ (function () {
    function AppComponent(_gridlayoutService, _sharedService) {
        this._gridlayoutService = _gridlayoutService;
        this._sharedService = _sharedService;
        this.gamificationExpand = true;
        this.helpExpand = true;
        this.badge = '';
        this.gridcss = 'RINALAYOUT';
        this.showPrev = false;
        this.showNext = false;
    }
    AppComponent.prototype.setLayout = function () {
        this.gridcss = this.gridcss + "-" + new Date().getTime();
        this.rinalayoutConfigDesktop1 = new amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["GridConfig"](this.gridcss, amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["GridConstants"].Desktop)
            .addlayout(["rinatenantbranding", "rinacustomerdemographics", "rinaproducts", "rinaproducts", "ringleftblock"])
            .addlayout(["rinaworkflows", "rinacentertablayout", "rinacentertablayout", "rinacentertablayout", "rinacentertablayout"]);
        this._gridlayoutService.createLayout(this.rinalayoutConfigDesktop1);
    };
    AppComponent.prototype.ngOnInit = function () {
        this.setLayout();
    };
    AppComponent.prototype.getDirection = function () {
        if (this.tenantId === 1002) {
            return "left";
        }
        else {
            return "right";
        }
    };
    AppComponent.prototype.isHCEnabled = function () {
        return (this.tenantId === 1002 || this.tenantId === 1004);
    };
    // calculateSize() {
    //   const customerDemographicsWidth = this.customerdemographics.nativeElement.clientWidth;
    //   this.griditemWidth = customerDemographicsWidth;
    //   setTimeout(() => {
    //     const nxt = this.productspanel.nativeElement;
    //     if (!((nxt.scrollWidth - nxt.offsetWidth - nxt.scrollLeft) <= this.griditemWidth)) {
    //       this.showNext = true;
    //     }
    //   }, 500);
    // }
    AppComponent.prototype.toggleHelp = function () {
        this.helpExpand = !this.helpExpand;
    };
    // onResize() {
    //   this.calculateSize();
    // }
    AppComponent.prototype.previous = function () {
        var prev = this.productspanel.nativeElement;
        prev.scrollLeft = prev.scrollLeft - (this.griditemWidth * 2) + 5;
        if (prev.scrollLeft <= this.griditemWidth) {
            this.showPrev = false;
        }
        this.showNext = true;
    };
    AppComponent.prototype.next = function () {
        var nxt = this.productspanel.nativeElement;
        nxt.scrollLeft = nxt.scrollLeft + (this.griditemWidth * 2) - 5;
        if ((nxt.scrollWidth - nxt.offsetWidth - nxt.scrollLeft) <= this.griditemWidth) {
            this.showNext = false;
        }
        this.showPrev = true;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('productspanel', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], AppComponent.prototype, "productspanel", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('customerdemographics', { read: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] }),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"])
    ], AppComponent.prototype, "customerdemographics", void 0);
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_1__["AmexioGridLayoutService"], _services_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! amexio-ng-extensions */ "./node_modules/amexio-ng-extensions/amexio-ng-extensions.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_layout_components_comapny_logo_company_logo_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../app/layout-components/comapny-logo/company.logo.component */ "./src/app/layout-components/comapny-logo/company.logo.component.ts");
/* harmony import */ var _app_layout_components_customer_demographic_customer_demographic_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../app/layout-components/customer-demographic/customer-demographic.component */ "./src/app/layout-components/customer-demographic/customer-demographic.component.ts");
/* harmony import */ var _app_layout_components_top_right_top_right_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../app/layout-components/top-right/top-right.component */ "./src/app/layout-components/top-right/top-right.component.ts");
/* harmony import */ var _app_layout_components_center_left_center_left_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../app/layout-components/center-left/center-left.component */ "./src/app/layout-components/center-left/center-left.component.ts");
/* harmony import */ var _app_layout_components_center_left_searchbox_searchbox_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../app/layout-components/center-left/searchbox/searchbox.component */ "./src/app/layout-components/center-left/searchbox/searchbox.component.ts");
/* harmony import */ var _app_layout_components_center_middle_center_middle_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../app/layout-components/center-middle/center-middle.component */ "./src/app/layout-components/center-middle/center-middle.component.ts");
/* harmony import */ var _app_layout_components_product_details_product_details_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../app/layout-components/product-details/product-details.component */ "./src/app/layout-components/product-details/product-details.component.ts");
/* harmony import */ var _layout_components_alert_window_alert_window_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./layout-components/alert-window/alert-window.component */ "./src/app/layout-components/alert-window/alert-window.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _app_layout_components_center_left_searchbox_searchbox_component__WEBPACK_IMPORTED_MODULE_12__["SearchBoxComponent"], _app_layout_components_product_details_product_details_component__WEBPACK_IMPORTED_MODULE_14__["ProductDetailsComponent"], _app_layout_components_comapny_logo_company_logo_component__WEBPACK_IMPORTED_MODULE_8__["CompanyLogoComponent"], _app_layout_components_center_middle_center_middle_component__WEBPACK_IMPORTED_MODULE_13__["CenterMiddleComponent"], _app_layout_components_center_left_center_left_component__WEBPACK_IMPORTED_MODULE_11__["CenterLeftComponent"], _app_layout_components_customer_demographic_customer_demographic_component__WEBPACK_IMPORTED_MODULE_9__["CustomerDemoGraphicComponent"], _app_layout_components_top_right_top_right_component__WEBPACK_IMPORTED_MODULE_10__["TopRightComponent"], _layout_components_alert_window_alert_window_component__WEBPACK_IMPORTED_MODULE_15__["AlertWindowComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioDashBoardModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioEnterpriseModule"], amexio_ng_extensions__WEBPACK_IMPORTED_MODULE_2__["AmexioWidgetModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"]
            ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["DatePipe"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/constants/service.constant.ts":
/*!***********************************************!*\
  !*** ./src/app/constants/service.constant.ts ***!
  \***********************************************/
/*! exports provided: BASE_URL, SERVICE_URL, SERVICE_URL_DEV */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BASE_URL", function() { return BASE_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICE_URL", function() { return SERVICE_URL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SERVICE_URL_DEV", function() { return SERVICE_URL_DEV; });
var BASE_URL = "http://34.74.53.19:3000/api";
var SERVICE_URL = {
    SEARCH_DETAILS: BASE_URL + '',
    MEMBER_SUMMARY: BASE_URL + '',
    CLAIMS_DATA: BASE_URL + '',
    FIND_RIGINATOR: BASE_URL + '',
    MEMBER_DETAILS: BASE_URL + '',
    MEMBER_CLAIM: BASE_URL + '',
    MEMBER_REHECTED_CLAIMS: BASE_URL + '',
    REJECTED_CLIAMS: BASE_URL + '',
    IBAAG_URL: BASE_URL + '',
    PASS_URL: BASE_URL + '',
    SERVICE_DATA: BASE_URL + '',
    PATA_DATA: BASE_URL + '',
    ICUE_NOTES: BASE_URL + ''
};
var SERVICE_URL_DEV = {
    SEARCH_DETAILS: BASE_URL + 'assets/data/search.json',
    MEMBER_SUMMARY: BASE_URL + 'assets/data/gotomembersummary.json',
    CLAIMS_DATA: BASE_URL + 'assets/data/claims.json',
    FIND_RIGINATOR: BASE_URL + 'assets/data/findOrginator.json',
    MEMBER_DETAILS: BASE_URL + 'assets/data/memberDetails.json',
    MEMBER_CLAIM: BASE_URL + 'assets/data/memberClaim.json',
    MEMBER_REHECTED_CLAIMS: BASE_URL + 'assets/data/memberrejectedclaim.json',
    REJECTED_CLIAMS: BASE_URL + 'assets/data/rejectedclaims.json',
    IBAAG_URL: BASE_URL + 'assets/data/IBaag.json',
    PASS_URL: BASE_URL + 'assets/data/pass.json',
    SERVICE_DATA: BASE_URL + 'assets/data/ibaagdropdown.json',
    PATA_DATA: BASE_URL + 'assets/data/padata.json',
    ICUE_NOTES: BASE_URL + 'assets/data/icuenotes.json'
};


/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-window-ce [(show)]=\"_sharedService.showAlertWindow\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\"\n    width=\"70%\" align=\"start\">\n    <amexio-header-ce align=\"left\" vertical-align=\"top\">\n        <amexio-label size=\"medium-bold\">Alert</amexio-label>\n    </amexio-header-ce>\n    <amexio-body-ce>\n        <ng-container *ngIf=\"rejectedclaimsData && rejectedclaimsData.length>0 ;else elseBlock\">\n            <b style=\"color:red\">Member has a rejected claim!</b>\n            <amexio-datagrid [height]=\"150\" [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"rejectedclaimsData\">\n                <amexio-data-table-column [width]=\"15\" [data-index]=\"'benifitlevel'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Benefit Level'\">\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"15\" [data-index]=\"'claimno'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Claim no.'\">\n                    <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n                        <a style=\"text-decoration:underline;\">{{row.claimno}}</a>\n                    </ng-template>\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"30\" [data-index]=\"'provider'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Provider'\">\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"15\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Status'\">\n                </amexio-data-table-column>\n                <amexio-data-table-column [width]=\"30\" [data-index]=\"'servicedate'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Service Date'\">\n                </amexio-data-table-column>\n            </amexio-datagrid>\n        </ng-container>\n        <ng-template #elseBlock>\n            <b style=\"color:red\">Member has no rejected claims</b>\n        </ng-template>\n    </amexio-body-ce>\n</amexio-window-ce>"

/***/ }),

/***/ "./src/app/layout-components/alert-window/alert-window.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/alert-window/alert-window.component.ts ***!
  \**************************************************************************/
/*! exports provided: AlertWindowComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertWindowComponent", function() { return AlertWindowComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AlertWindowComponent = /** @class */ (function () {
    function AlertWindowComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.showAlertWindow = false;
        this.rejectedclaimsData = [];
        this._sharedService.rejectedClaimData.subscribe(function (data) {
            if (data !== null && data !== undefined && data && data.length > 0) {
                setTimeout(function () {
                    _this.rejectedclaimsData = Object.assign([], data);
                    _this._sharedService.showAlertWindow = true;
                    _this._sharedService.showAlert = true;
                }, 100);
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.rejectedclaimsData = [];
            _this._sharedService.showLoader = false;
        });
    }
    AlertWindowComponent.prototype.ngOnInit = function () {
    };
    AlertWindowComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'alert-window',
            template: __webpack_require__(/*! ./alert-window.component.html */ "./src/app/layout-components/alert-window/alert-window.component.html"),
            styles: [__webpack_require__(/*! ./alert-window.component.css */ "./src/app/layout-components/alert-window/alert-window.component.css")]
        }),
        __metadata("design:paramtypes", [_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], AlertWindowComponent);
    return AlertWindowComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/center-left/center-left.component.html":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/center-left/center-left.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"true\" [footer]=\"true\" [footer-align]=\"'center'\" [body-height]=\"55\">\n  <amexio-header>\n      MEMBER SEARCH\n  </amexio-header>\n  <amexio-body>\n    <amexio-row>\n      <amexio-column [size]=\"12\">\n        <search-box (search)=\"searchHandle($event)\" [isSearchDisble]=\"_sharedService.searchdisble\"></search-box>\n      </amexio-column>\n    </amexio-row>\n    <amexio-row>\n      <amexio-column [size]=\"12\">\n        <br>\n        <div *ngFor=\"let workflow of workflowList;let i = index\">\n        <div [ngStyle]=\"{'padding': i== 2 ? '10px 2px 5px 2px' :'2px 2px 5px 2px'}\">\n          <amexio-button  [label]=\"workflow.workflowName\" [type]=\"'theme-color'\" (onClick)=\"workflowHandle(workflow)\"\n            [tooltip]=\"'large'\" [disabled]=\"workflow.disabled\" [block]=\"true\">\n          </amexio-button>\n        </div>\n        </div>\n      </amexio-column>\n    </amexio-row>\n  </amexio-body>\n  <amexio-action>\n    <amexio-row>\n      <amexio-column size=\"12\">\n        <div style=\"display: inline-flex; justify-content: center; width:100%;\">\n          <i style=\"margin: 5px\" class=\"fa fa-sun-o\"></i>\n          <amexio-darkmode [size]=\"'small'\" [type]=\"2\"></amexio-darkmode>\n          <i style=\"margin: 5px\" class=\"fa fa-moon-o\"></i>\n        </div>\n      </amexio-column>\n    </amexio-row>\n  </amexio-action>\n</amexio-card>\n<alert-window></alert-window>"

/***/ }),

/***/ "./src/app/layout-components/center-left/center-left.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/layout-components/center-left/center-left.component.ts ***!
  \************************************************************************/
/*! exports provided: CenterLeftComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CenterLeftComponent", function() { return CenterLeftComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/rest.call.service */ "./src/app/services/rest.call.service.ts");
/* harmony import */ var src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/constants/service.constant */ "./src/app/constants/service.constant.ts");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 25/7/19.
 */





var CenterLeftComponent = /** @class */ (function () {
    function CenterLeftComponent(date, _rCallService, _sharedService) {
        var _this = this;
        this.date = date;
        this._rCallService = _rCallService;
        this._sharedService = _sharedService;
        this.workflowList = [];
        this.enableWindow = false;
        this.enablegamification = false;
        this.msgData = [];
        this.getWorkflowList();
        this._sharedService.selectMember.subscribe(function (value) {
            _this.workflowList[0].disabled = !value;
            _this.workflowList[1].disabled = !value;
            _this.workflowList[2].disabled = !value;
        });
    }
    CenterLeftComponent.prototype.ngOnInit = function () {
    };
    CenterLeftComponent.prototype.ngOnDestroy = function () {
        this.subscription1.unsubscribe();
        this.subscription2.unsubscribe();
    };
    CenterLeftComponent.prototype.getWorkflowList = function () {
        this.workflowList = [{
                "workflowName": "MEMBER IS ORIGINATOR",
                "disabled": true,
                "value": 1
            },
            {
                "workflowName": "FIND ORIGINATOR",
                "disabled": true,
                "value": 2
            }, {
                "workflowName": "PRIOR AUTHORIZATION",
                "disabled": true,
                "value": 3
            }];
    };
    CenterLeftComponent.prototype.searchHandle = function (searchObject) {
        var _this = this;
        this._sharedService.searchdisble = true;
        this._sharedService.resetData();
        this._sharedService.showLoader = true;
        var requestJson;
        requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "Search EandI",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "memberID": searchObject.memberId,
                    "FirstName": searchObject.firstName,
                    "LastName": searchObject.lastName,
                    "DOB": this.date.transform(searchObject.dob, 'MM/dd/yyyy')
                }
            }
        };
        var resp;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].SEARCH_DETAILS, requestJson).subscribe(function (res) {
            resp = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addSearchResponse(resp);
            _this._sharedService.updateSelectMemberFlag(false);
        });
    };
    CenterLeftComponent.prototype.workflowHandle = function (workFlow) {
        this._sharedService.showLoader = true;
        if (workFlow.value === 1) {
            this.getmemberDetails();
        }
        else if (workFlow.value === 2) {
            this.workflowList[0].disabled = true;
            this.findOriginator();
        }
        else if (workFlow.value === 3) {
            this.getPaData();
        }
    };
    CenterLeftComponent.prototype.getmemberDetails = function () {
        var _this = this;
        var memberRequestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "Subject Is Originator EandI",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].MEMBER_DETAILS, memberRequestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addSelectedMember(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getRejectedClaimData(memberRequestJson);
            }
        });
    };
    CenterLeftComponent.prototype.getRejectedClaimData = function (requsetjson) {
        var _this = this;
        var requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "Subject Is Originator EandI",
                    "requestId": requsetjson.Data.RequestMetaData.requestId,
                    "requestTime": requsetjson.Data.RequestMetaData.requestTime,
                    "commandSeqId": 2
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].REJECTED_CLIAMS, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.getRejectedClaims(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getClaims(requestJson);
            }
        });
    };
    CenterLeftComponent.prototype.getClaims = function (request) {
        var _this = this;
        var requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "Subject Is Originator EandI",
                    "requestId": request.Data.RequestMetaData.requestId,
                    "requestTime": request.Data.RequestMetaData.requestTime,
                    "commandSeqId": 3
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].CLAIMS_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.setClaimsData(response);
        });
    };
    CenterLeftComponent.prototype.findOriginator = function () {
        var _this = this;
        var requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "Find Originator EandI",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].FIND_RIGINATOR, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.findoriginator(response);
        });
    };
    CenterLeftComponent.prototype.getPaData = function () {
        var _this = this;
        this._sharedService.showLoader = true;
        var requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "EandIPA",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {}
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_2__["SERVICE_URL"].PATA_DATA, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.getPaData(response);
        });
    };
    CenterLeftComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'center-left',
            template: __webpack_require__(/*! ./center-left.component.html */ "./src/app/layout-components/center-left/center-left.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"], src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_1__["RestCallService"], _services_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"]])
    ], CenterLeftComponent);
    return CenterLeftComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/center-left/searchbox/searchbox.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/layout-components/center-left/searchbox/searchbox.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-number-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'MEMBER ID'\" [(ngModel)]=\"searchModel.memberId\">\n</amexio-number-input>\n<amexio-row>\n   <amexio-column [size] =12 >\n      \n   </amexio-column>\n</amexio-row>\n<amexio-text-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'FIRST NAME'\" [(ngModel)]=\"searchModel.firstName\">\n</amexio-text-input>\n<amexio-text-input [field-label]=\"''\" name=\"name\" [place-holder]=\"'LAST NAME'\" [(ngModel)]=\"searchModel.lastName\">\n</amexio-text-input>\n<amexio-date-time-picker [place-holder]=\"'DOB'\" [date-picker]=\"true\" [(ngModel)]=\"searchModel.dob\">\n</amexio-date-time-picker>\n<amexio-layout-columns [fit]=\"true\" [border]=\"false\" [orientation]=\"'horizontal'\" [alignment]=\"'end'\">\n   <amexio-layout-item>\n      <amexio-button [disabled]=\"isSearchDisble\" [label]=\"'Search'\" [type]=\"'theme-color'\" [tooltip]=\"'large'\" [block]=\"false\"\n         (onClick)=\"onSearchClick()\">\n      </amexio-button>\n   </amexio-layout-item>\n</amexio-layout-columns>\n"

/***/ }),

/***/ "./src/app/layout-components/center-left/searchbox/searchbox.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/layout-components/center-left/searchbox/searchbox.component.ts ***!
  \********************************************************************************/
/*! exports provided: SearchBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchBoxComponent", function() { return SearchBoxComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _model_searchm_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../model/searchm.model */ "./src/app/model/searchm.model.ts");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */




var SearchBoxComponent = /** @class */ (function () {
    function SearchBoxComponent(_httpClient, _sharedService) {
        this._httpClient = _httpClient;
        this._sharedService = _sharedService;
        this.showDropdown = false;
        this.dropDownItemList = [];
        this.searchId = '';
        this.searchType = 1;
        this.isSearchDisble = false;
        this.search = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.searchModel = new _model_searchm_model__WEBPACK_IMPORTED_MODULE_2__["SearchModel"]();
    }
    SearchBoxComponent.prototype.ngOnInit = function () {
    };
    SearchBoxComponent.prototype.onSearchClick = function () {
        this.search.emit(this.searchModel);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('isSearchDisble'),
        __metadata("design:type", Object)
    ], SearchBoxComponent.prototype, "isSearchDisble", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], SearchBoxComponent.prototype, "search", void 0);
    SearchBoxComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'search-box',
            template: __webpack_require__(/*! ./searchbox.component.html */ "./src/app/layout-components/center-left/searchbox/searchbox.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"]])
    ], SearchBoxComponent);
    return SearchBoxComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.css":
/*!*****************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.css ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "amexio-layout-columns amexio-layout-item {\n    padding: 5px 0px 5px 5px;\n}\n\n.memberdetails{\n    display: block;\n    font-size: 14px !important;\n}\n\ntable {\n  border-collapse: collapse;\n}\n\ntable, td {\n  border: 1px solid gray;\n  padding: 5px;\n  text-align: left\n}"

/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.html":
/*!******************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.html ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [footer-align]=\"'center'\">\n  <amexio-body>\n    <amexio-tab-view [active-bg-color]=\"true\" [divide-header-equally]=\"true\" [closable]=\"false\" [body-height]=\"52\" >\n      <amexio-tab title=\"MEMEBER DETAILS\" [active]=\"true\">\n        <amexio-datagrid class=\"memberdetails\" *ngIf=\"memberDetailsOriginator && memberDetailsOriginator.length <= 0\" [page-size]=\"10\"\n          [enable-column-filter]=\"false\" [data]=\"memberDetails\">\n          <amexio-data-table-column [width]=\"4\" [data-type]=\"'string'\" [hidden]=\"false\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\" let-index=\"index\">\n              <input style=\"width: 1.5em; height: 1.5em;\" type=\"radio\" name=\"check\" value=\"row.radioId\" (click)=\"getSelectedRecord(row)\">\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'source'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'SOURCE'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [sort]=\"false\" [data-index]=\"'lastname'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'LAST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'firstname'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'FIRST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'mm'\" [data-type]=\"'string'\" [hidden]=\"true\" [text]=\"'MM'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"7\" [data-index]=\"'eeid'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'EEID'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'dob'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'DOB'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"11\" [data-index]=\"'relationship'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'RELATIONSHIP'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'policy'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'POLICY#'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'gender'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'GENDER'\">\n          </amexio-data-table-column>\n          <!-- <amexio-data-table-column [width]=\"7\" [data-index]=\"'address'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'ADDRESS'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"4\" [data-index]=\"'city'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'CITY'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"4\" [data-index]=\"'state'\" [data-type]=\"'string'\" [hidden]=\"false\"\n            [text]=\"'STATE'\">\n          </amexio-data-table-column> -->\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'zipCode'\" [data-type]=\"'string'\" [hidden]=\"true\" [text]=\"'ZIPCODE'\">\n          </amexio-data-table-column>\n        </amexio-datagrid>\n        <amexio-datagrid *ngIf=\"memberDetailsOriginator && memberDetailsOriginator.length>0\" [page-size]=\"10\" [enable-column-filter]=\"false\"\n          [data]=\"memberDetailsOriginator\">\n          <amexio-data-table-column [width]=\"4\" [data-type]=\"'string'\" [hidden]=\"false\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <!-- <amexio-radio-group name=\"check\" [http-method]=\"'get'\" [data-reader]=\"'data'\" [http-url]=\"'assets/radiogroup.json'\" [value-field]=\"'radioId'\"\n                [(ngModel)]=\"radioId\" (onSelection)=\"getMemberSummaryRecord($event,row)\">\n              </amexio-radio-group> -->\n              <input style=\"width: 1.5em; height: 1.5em;\" type=\"radio\" name=\"check\" value=\"row.radioId\" (click)=\"getMemberSummaryRecord(row)\">\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [sort]=\"false\" [data-index]=\"'lastname'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'LAST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [data-index]=\"'firstname'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'FIRST NAME'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [data-index]=\"'dob'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'DOB'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [data-index]=\"'relationship'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'RELATIONSHIP'\">\n          </amexio-data-table-column>\n        </amexio-datagrid>\n        <amexio-row>\n          <amexio-column>\n            <amexio-button [disabled]=\"isMemSummaryEnable\" *ngIf=\"memberDetailsOriginator && memberDetailsOriginator.length>0\" (onClick)=\"getMemberSummary()\"\n              [label]=\"'GO TO MEMBER SUMMARY'\" [type]=\"'theme-color'\">\n            </amexio-button>\n          </amexio-column>\n        </amexio-row>\n      </amexio-tab>\n      <amexio-tab title=\"CLAIMS\">\n        <amexio-datagrid class=\"claimgrid\" [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"claimsData\">\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'claimno'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Claim No.'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <a style=\"text-decoration:underline;\">{{row.claimno}}</a>\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"12\" [data-index]=\"'benifitlevel'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Benefit Level'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Status'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <a style=\"color:red;\">{{row.status}}</a>\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"15\" [data-index]=\"'providername'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Provider'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"25\" [data-index]=\"'processeddate'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Service Date / Processed Date'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <table style=\"width:100%\">\n                <tr *ngFor=\"let item of row.servicedates;let i = index;\">\n                  <td>{{item}}</td>\n                  <td>{{row.processeddate[i]}}</td>\n                </tr>\n              </table>\n            </ng-template>\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"40\" [data-index]=\"''\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Procedure Code / Rejection Code / Reason For Rejection'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <table style=\"width:100%\">\n                <tr *ngFor=\"let item of row.rejectioncode;let i = index;\">\n                  <td (click)=\"onclaimhoverClick(row,i)\">{{row.procedurecode[i]}}</td>\n                  <td  (click)=\"onclaimhoverClick(row,i)\">{{item}}</td>\n                  <td (click)=\"onclaimhoverClick(row,i)\">{{row.reasonforrejection[i]}}</td>\n                  \n                </tr>\n              </table>\n            </ng-template>\n          </amexio-data-table-column>\n            <amexio-data-table-column  [data-index]=\"'hover'\" [data-type]=\"'string'\" [hidden]=\"true\"\n            [text]=\"''\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"10\" [data-index]=\"'action'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Action'\">\n            <ng-template #amexioBodyTmpl let-column let-row=\"row\">\n              <amexio-button (onClick)=\"onPassClick(row)\" [label]=\"row.action\" [type]=\"'theme-color'\">\n              </amexio-button>\n            </ng-template>\n          </amexio-data-table-column>\n        </amexio-datagrid>\n      </amexio-tab>\n      <amexio-tab title=\"PA\" [disabled]=\"false\">\n        <amexio-datagrid  *ngIf=\"paData && paData.length > 0 && padataflag\" class=\"memberdetails\" [page-size]=\"10\" [enable-column-filter]=\"false\" [data]=\"paData\" (rowSelect)=\"onpaDataclick($event)\">\n          <amexio-data-table-column [width]=\"7\" [data-index]=\"'recordtype'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Record Type'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [sort]=\"false\" [data-index]=\"'number'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Number'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"7\" [data-index]=\"'firstname'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'First Name'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"9\" [data-index]=\"'relationship'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Relationship'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"8\" [data-index]=\"'patientstatus'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Patient Status'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"7\" [data-index]=\"'diagnosis'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Diagnosis'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'from'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'From'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'to'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'To'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"5\" [data-index]=\"'paid'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Paid'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'reason'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Reason'\">\n          </amexio-data-table-column>\n          <amexio-data-table-column [width]=\"6\" [data-index]=\"'taxid'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Tax Id'\">\n          </amexio-data-table-column>\n        </amexio-datagrid>\n            <b  *ngIf=\"!padataflag\" style=\"color:red\">No results found</b>\n            <br><br>\n      </amexio-tab>\n      <amexio-tab title=\"PLAN DETAILS\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"SERVICE REQUESTS\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"INTERACTION HISTORY\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n      <amexio-tab title=\"MARKETING HISTORY\" [disabled]=\"true\">\n        Education Nullam nec dolor lobortis, dictum dolor ac, suscipit massa. Donec id suscipit nisi. Nunc sit amet aliquet risus.\n        Aenean placerat suscipit risus at mollis. Quisque eleifend gravida scelerisque. In non eleifend nisi. Phasellus tempor\n        hendrerit posuere. Praesent ornare rutrum mi et condimentum.\n      </amexio-tab>\n    </amexio-tab-view>\n    <div style=\"padding: 10px 10px 0px 10px; background-color: var(--appBackground);\">\n      <amexio-row>\n        <amexio-column [size]=12>\n          <amexio-checkbox-group [http-url]=\"'assets/querycheckbox.json'\" [http-method]=\"'get'\" [data-reader]=\"'data'\" [display-field]=\"'name'\"\n            [horizontal]=\"true\" [value-field]=\"'checked'\">\n          </amexio-checkbox-group>\n        </amexio-column>\n      </amexio-row>\n      <amexio-layout-columns [border]=\"false\" [fit]=\"true\" [orientation]=\"'horizontal'\" [alignment]=\"'space-between'\">\n        <amexio-layout-item style=\"width:95%\">\n          <amexio-text-input name=\"name\" icon-feedback=\"true\">\n          </amexio-text-input>\n        </amexio-layout-item>\n        <amexio-layout-item>\n          <amexio-button [label]=\"'Submit'\" [type]=\"'theme-color'\">\n          </amexio-button>\n        </amexio-layout-item>\n      </amexio-layout-columns>\n    </div>\n  </amexio-body>\n</amexio-card>\n<amexio-window-ce [(show)]=\"showIBag\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"70%\" (close)=\"CloseIbaag()\">\n  <amexio-header-ce vertical-align=\"top\" border-bottom=\"true\">\n    <amexio-label size=\"small-bold\"> IBAAG TOOLBAR</amexio-label>\n  </amexio-header-ce>\n  <amexio-body-ce height=\"600px\">\n    claim # : {{claimno}} <br>\n    <amexio-dropdown [(ngModel)]=\"ibagservice\" [place-holder]=\"'Select'\" name=\"service\" [(ngModel)]=\"service\" [allow-blank]=\"false\"\n      [error-msg]=\"'Select Document'\" [data]=\"serviceData\" [display-field]=\"'primarydisplay'\" [value-field]=\"'primarydisplay'\"\n      [search]=\"true\" (onSingleSelect)=\"onServiceSelect($event)\">\n    </amexio-dropdown>\n    <br>\n    <iframe *ngIf=\"ifram\" style=\"width: 100%; height: 600px;\" [src]=\"urlSafe\" frameborder=\"1\" allowfullscren=\"allowfullscren\"></iframe>\n  </amexio-body-ce>\n</amexio-window-ce>\n<amexio-window-ce  [(show)]=\"passplan\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"40%\">\n  <amexio-header-ce vertical-align=\"top\" border-bottom=\"true\">\n    <amexio-label size=\"small-bold\"> CO-PAY VALIDATION</amexio-label>\n  </amexio-header-ce>\n  <amexio-body-ce>\n    <ng-container *ngIf=\"passData.length>0\">\n    <p>    claim # : {{claimno}}</p>\n    <p>Physician office visit: {{passData[0].physicianofficevisit}}</p>\n    <p>Specialist Physician office visit: {{passData[0].specialistphysicianofficevisit}}</p>\n<p> Urgent Care Center: {{passData[0].urgentcarecenter}}</p>\n    </ng-container>\n  </amexio-body-ce>\n</amexio-window-ce>\n<amexio-window-ce [(show)]=\"patientStatusWindow\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"70%\">\n  <amexio-header-ce vertical-align=\"top\" border-bottom=\"true\">\n    <amexio-label size=\"small-bold\"> {{patientStatus}}</amexio-label>\n  </amexio-header-ce>\n  <amexio-body-ce height=\"auto\">\n    <amexio-datagrid class=\"memberdetails\" *ngIf=\"inpatientdeatils && inpatientdeatils.length>0\" [page-size]=\"10\" [enable-column-filter]=\"false\"\n      [data]=\"inpatientdeatils\">\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'procedure'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Procedure'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [sort]=\"false\" [data-index]=\"'programdescription'\" [data-type]=\"'string'\" [hidden]=\"false\"\n        [text]=\"'Program Description'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'programtype'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Program Type'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Status'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'writtencomment'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Written Comment'\">\n      </amexio-data-table-column>\n        <amexio-data-table-column [width]=\"10\" [data-index]=\"'serviceprovidertin'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Service Provider Tin'\">\n      </amexio-data-table-column>\n    </amexio-datagrid>\n    <amexio-datagrid class=\"memberdetails\" *ngIf=\"outpatientDetails && outpatientDetails.length>0\" [page-size]=\"10\" [enable-column-filter]=\"false\"\n      [data]=\"outpatientDetails\">\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'procedure'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Procedure'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'programtype'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Program Type'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'from'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'From'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'to'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'To'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'status'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Status'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"15\" [data-index]=\"'writtencomment'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Written Comment'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"10\" [data-index]=\"'allowedunits'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Allowed Units'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"15\" [data-index]=\"'remainingunits'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Remaining Units'\">\n      </amexio-data-table-column>\n    </amexio-datagrid>\n  </amexio-body-ce>\n  <amexio-action-ce align=\"center\">\n    <amexio-button (onClick)=\"onIcueClick()\" [label]=\"'ICUE Notes'\" [type]=\"'theme-color'\">\n    </amexio-button>\n  </amexio-action-ce>\n</amexio-window-ce>\n\n<amexio-window-ce [(show)]=\"icueWindow\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"70%\">\n  <amexio-header-ce vertical-align=\"top\" border-bottom=\"true\">\n    <amexio-label size=\"small-bold\"> ICUE Notes</amexio-label>\n  </amexio-header-ce>\n  <amexio-body-ce height=\"auto\">\n    <ng-container *ngIf=\"icueDetails && icueDetails.length > 0;else elseBlock\">\n    <amexio-datagrid  class=\"memberdetails\" [height]=\"400\"  [page-size]=\"10\" [enable-column-filter]=\"false\"\n      [data]=\"icueDetails\">\n      <amexio-data-table-column [width]=\"25\" [data-index]=\"'createddatetime'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Created Date/Time'\">\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"25\" [data-index]=\"'createdby'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Created By'\">\n       <ng-template #amexioBodyTmpl let-column let-row=\"row\" let-index=\"index\">\n<div [innerHTML]=\"row.createdby\"></div>          \n  </ng-template>\n      </amexio-data-table-column>\n      <amexio-data-table-column [width]=\"50\" [data-index]=\"'notes'\" [data-type]=\"'string'\" [hidden]=\"false\" [text]=\"'Notes'\">\n       <ng-template #amexioBodyTmpl let-column let-row=\"row\" let-index=\"index\">\n<div [innerHTML]=\"row.notes\"></div>          \n  </ng-template>\n      </amexio-data-table-column>\n    </amexio-datagrid>\n    </ng-container>\n     <ng-template #elseBlock>\n            <b style=\"color:red\">No results found</b>\n            <br><br>\n        </ng-template>\n  </amexio-body-ce>\n</amexio-window-ce>\n<amexio-window-ce [(show)]=\"showRelativePanel1\" [horizontal-position]=\"'center'\" [vertical-position]=\"'center'\" width=\"50%\">\n  <amexio-body-ce>\n     <div [innerHTML]=\"hoverData\"></div>\n  </amexio-body-ce>\n</amexio-window-ce>\n<alert-window></alert-window>"

/***/ }),

/***/ "./src/app/layout-components/center-middle/center-middle.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/center-middle/center-middle.component.ts ***!
  \****************************************************************************/
/*! exports provided: CenterMiddleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CenterMiddleComponent", function() { return CenterMiddleComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/rest.call.service */ "./src/app/services/rest.call.service.ts");
/* harmony import */ var src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/constants/service.constant */ "./src/app/constants/service.constant.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 25/7/19.
 */






var CenterMiddleComponent = /** @class */ (function () {
    function CenterMiddleComponent(_rCallService, _sharedService, sanitizer, _http) {
        var _this = this;
        this._rCallService = _rCallService;
        this._sharedService = _sharedService;
        this.sanitizer = sanitizer;
        this._http = _http;
        this.memberDetails = [];
        this.memberDetailsOriginator = [];
        this.claimsData = [];
        this.radioCheck = "1";
        this.isMemSummaryEnable = true;
        this.showIBag = false;
        this.passplan = false;
        this.ifram = false;
        this.serviceData = [];
        this.passData = [];
        this.patientStatusWindow = false;
        this.inPatientData = [];
        this.outpatientData = [];
        this.inpatientdeatils = [];
        this.outpatientDetails = [];
        this.icueData = [];
        this.icueDetails = [];
        this.icueWindow = false;
        this.padataflag = true;
        this.showRelativePanel1 = false;
        this.ibaagdropdownData();
        this._sharedService.searchResponse.subscribe(function (data) {
            _this.memberDetailsOriginator = [];
            _this._sharedService.showAlert = false;
            if (data) {
                var max_1 = 10;
                data.forEach(function (object, index) {
                    object['radioId'] = Math.floor(Math.random() * max_1 + 1);
                    object['index'] = index;
                });
            }
            _this.memberDetails = Object.assign([], data);
            _this._sharedService.searchdisble = false;
            _this._sharedService.showLoader = false;
        });
        this._sharedService.padata.subscribe(function (data) {
            _this.paData = [];
            if (data) {
                setTimeout(function () {
                    _this.paData = Object.assign([], data.padetails);
                    _this.inPatientData = Object.assign([], data.inpadetails);
                    _this.outpatientData = Object.assign([], data.outpadetails);
                    _this.icueData = Object.assign([], data.icuenotes);
                    if (_this.paData && _this.paData.length > 0) {
                        _this.padataflag = true;
                    }
                    else if (_this.paData && _this.paData.length == 0) {
                        _this.padataflag = false;
                    }
                }, 100);
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.claimsData.subscribe(function (data) {
            if (data != null) {
                data.forEach(function (obj) {
                    if (obj["rejectioncode"] || obj["reasonforrejection"] || obj["processeddate"] || obj["procedurecode"]) {
                        obj["rejectioncode"] = obj.rejectioncode.split("+");
                        obj["reasonforrejection"] = obj.reasonforrejection.split("+");
                        obj["servicedates"] = obj.servicedates.split("+");
                        obj["processeddate"] = obj.processeddate.split("+");
                        obj["procedurecode"] = obj.procedurecode.split("+");
                        obj["hover"] = obj.hover.split("+");
                        obj["rejectioncode"] = obj["rejectioncode"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["reasonforrejection"] = obj["reasonforrejection"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["servicedates"] = obj["servicedates"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["processeddate"] = obj["processeddate"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["procedurecode"] = obj["procedurecode"].filter(function (msg) { return msg.trim().length > 0; });
                        obj["hover"] = obj["hover"].filter(function (msg) { return msg.trim().length > 0; });
                    }
                });
                _this.claimsData = Object.assign([], data);
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.claimsData = [];
            _this.memberDetails = [];
            _this.paData = [];
            _this.inPatientData = [];
            _this.outpatientData = [];
            _this.icueData = [];
        });
        this._sharedService.ibaagResponse.subscribe(function (data) {
            if (data != null) {
                _this.IBaagUrl = data[0].url;
                _this.showIBag = true;
            }
            _this._sharedService.showLoader = false;
        });
        this._sharedService.passData.subscribe(function (data) {
            setTimeout(function () {
                if (data != null) {
                    _this.passData = data;
                    _this.passplan = !_this.passplan;
                }
            }, 0);
            _this._sharedService.showLoader = false;
        });
        this._sharedService.originatorData.subscribe(function (data) {
            if (data != null) {
                _this.memberDetails = [];
                _this.memberDetailsOriginator = Object.assign([], data);
                if (_this.memberDetailsOriginator) {
                    var max_2 = 20;
                    _this.memberDetailsOriginator.forEach(function (object, index) {
                        object['radioId'] = Math.floor(Math.random() * max_2 + 1);
                        object['index'] = index;
                    });
                }
            }
            _this._sharedService.showLoader = false;
        });
        this.radioGroupData = [{
                "radioId": 1
            }
        ];
    }
    CenterMiddleComponent.prototype.ngOnInit = function () {
    };
    CenterMiddleComponent.prototype.onServiceSelect = function (event) {
        var url;
        url = this.IBaagUrl + "#" + event.primarydisplay;
        this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(url);
        this.ifram = true;
    };
    CenterMiddleComponent.prototype.CloseIbaag = function () {
        this.urlSafe = '';
        this.ibagservice = '';
        this.ifram = false;
        this.showIBag = false;
    };
    CenterMiddleComponent.prototype.getSelectedRecord = function (row) {
        this._sharedService.updateSelectMemberFlag(true);
        this._sharedService.index = row.index;
    };
    CenterMiddleComponent.prototype.getMemberSummary = function () {
        this._sharedService.showLoader = true;
        this.memberSummary();
    };
    CenterMiddleComponent.prototype.memberSummary = function () {
        var _this = this;
        var requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "Go To Member EandI",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].MEMBER_SUMMARY, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.addSelectedMember(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getRejectedClaimData(requestJson);
            }
        });
    };
    CenterMiddleComponent.prototype.getRejectedClaimData = function (requsetjson) {
        var _this = this;
        var requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "Go To Member EandI",
                    "requestId": requsetjson.Data.RequestMetaData.requestId,
                    "requestTime": requsetjson.Data.RequestMetaData.requestTime,
                    "commandSeqId": 2
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].MEMBER_REHECTED_CLAIMS, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.getRejectedClaims(response);
            if (!response.Data.ResponseMetaData.completed && (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success)) {
                _this.getCliams(requestJson);
            }
        });
    };
    CenterMiddleComponent.prototype.getCliams = function (request) {
        var _this = this;
        var requestJson = {
            "Initial": false,
            "Data": {
                "RequestMetaData": {
                    "Command": "Go To Member EandI",
                    "requestId": request.Data.RequestMetaData.requestId,
                    "requestTime": request.Data.RequestMetaData.requestTime,
                    "commandSeqId": 3
                },
                "RequestParams": {
                    "Index": this._sharedService.index
                }
            }
        };
        var response;
        this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].MEMBER_CLAIM, requestJson).subscribe(function (res) {
            response = res;
        }, function (error) {
            _this._sharedService.showLoader = false;
        }, function () {
            _this._sharedService.setClaimsData(response);
            _this._sharedService.showLoader = false;
        });
    };
    CenterMiddleComponent.prototype.getMemberSummaryRecord = function (row) {
        this.isMemSummaryEnable = false;
        this._sharedService.index = row.index;
    };
    CenterMiddleComponent.prototype.onPassClick = function (row) {
        var _this = this;
        var requestJson = {
            "Initial": true,
            "Data": {
                "RequestMetaData": {
                    "Command": "EandIAction",
                    "requestId": this._sharedService.getRequestId(),
                    "requestTime": this._sharedService.getRequestTime(),
                    "commandSeqId": 1
                },
                "RequestParams": {
                    "Action": row.action
                }
            }
        };
        if (row.action.toLowerCase() == 'pass') {
            this.claimno = row.claimno;
            var response_1;
            this._sharedService.showLoader = true;
            this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].PASS_URL, requestJson).subscribe(function (res) {
                response_1 = res;
            }, function (error) {
                _this._sharedService.showLoader = false;
            }, function () {
                _this._sharedService.getpassData(response_1);
            });
        }
        else if (row.action.toLowerCase() == 'ibaag') {
            this.ibaagdropdownData();
            this.claimno = row.claimno;
            this.ibagservice = '';
            this.ifram = false;
            var response_2;
            this._sharedService.showLoader = true;
            this._rCallService.getCall(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].IBAAG_URL, requestJson).subscribe(function (res) {
                response_2 = res;
            }, function (error) {
                _this._sharedService.showLoader = false;
            }, function () {
                _this._sharedService.getClaimActionData(response_2);
            });
        }
    };
    CenterMiddleComponent.prototype.getIBaagdropdownData = function () {
        var _this = this;
        var response;
        this._http.get(src_app_constants_service_constant__WEBPACK_IMPORTED_MODULE_3__["SERVICE_URL"].SERVICE_DATA).subscribe(function (res) {
            response = res;
        }, function (error) {
        }, function () {
            _this.serviceData = response;
        });
    };
    CenterMiddleComponent.prototype.onpaDataclick = function (event) {
        this.patientStatus = event.patientstatus;
        this._sharedService.index = event.index;
        if (event.patientstatus == "In-Patient") {
            this.outpatientDetails = [];
            this.inpatientdeatils = [];
            this.inpatientdeatils = this.inPatientData.filter(function (msg) { return msg.index == event.index; });
            this.patientStatusWindow = true;
        }
        else if (event.patientstatus == "Out-Patient") {
            this.inpatientdeatils = [];
            this.outpatientDetails = [];
            this.outpatientDetails = this.outpatientData.filter(function (msg) { return msg.index == event.index; });
            this.patientStatusWindow = true;
        }
    };
    CenterMiddleComponent.prototype.onIcueClick = function () {
        var _this = this;
        this.patientStatusWindow = false;
        this.icueDetails = [];
        this.icueDetails = this.icueData.filter(function (msg) { return msg.index == _this._sharedService.index; });
        this.icueWindow = true;
    };
    CenterMiddleComponent.prototype.onclaimhoverClick = function (row, index) {
        this.hoverData = [];
        this.hoverData = row.hover[index];
        this.showRelativePanel1 = true;
    };
    CenterMiddleComponent.prototype.onLeaveRelativePanel = function () {
        this.hoverData = [];
        this.showRelativePanel1 = !this.showRelativePanel1;
    };
    CenterMiddleComponent.prototype.onCloseRelativePanel = function (event) {
        this.showRelativePanel1 = event.showRelativePanel1;
    };
    CenterMiddleComponent.prototype.ibaagdropdownData = function () {
        this.serviceData = [
            {
                "primarydisplay": "Accessing_Benefits"
            },
            {
                "primarydisplay": "Acupuncture_Services"
            },
            {
                "primarydisplay": "Allergy_Injections"
            },
            {
                "primarydisplay": "Allowed_Amount_Eligible_Expenses"
            },
            {
                "primarydisplay": "Ambulance_Services_Emergency"
            },
            {
                "primarydisplay": "Ambulance_Services_NonEmergency"
            },
            {
                "primarydisplay": "Annual_Deductible"
            },
            {
                "primarydisplay": "Annual_Drug_Deductible"
            },
            {
                "primarydisplay": "Autism_Spectrum_Disorder_Inpatient"
            },
            {
                "primarydisplay": "Autism_Spectrum_Disorder_Outpatient"
            },
            {
                "primarydisplay": "Bariatric_Obesity_Surgery"
            },
            {
                "primarydisplay": "Bariatric_Resource_Services_BRS"
            },
            {
                "primarydisplay": "Breast_Pumps"
            },
            {
                "primarydisplay": "CAC_Consumer_Accounts_Card"
            },
            {
                "primarydisplay": "COBRA_Information"
            },
            {
                "primarydisplay": "Cant_Find_What_You_Are_Looking_For"
            },
            {
                "primarydisplay": "Care_Management"
            },
            {
                "primarydisplay": "Chemical_Dependency"
            },
            {
                "primarydisplay": "Chiropractic_Services"
            },
            {
                "primarydisplay": "Clinical_Trials"
            },
            {
                "primarydisplay": "Coinsurance"
            },
            {
                "primarydisplay": "Coinsurance_box"
            },
            {
                "primarydisplay": "Congenital_Heart_Disease_Resource_Servic"
            },
            {
                "primarydisplay": "Congenital_Heart_Disease_Surgeries"
            },
            {
                "primarydisplay": "Coordination_of_Benefits"
            },
            {
                "primarydisplay": "Copayment"
            },
            {
                "primarydisplay": "Deductibles"
            },
            {
                "primarydisplay": "Dental_Anesthesia"
            },
            {
                "primarydisplay": "Dental_Anesthesia_Services "
            },
            {
                "primarydisplay": "Dental_Services_Accident_Only"
            },
            {
                "primarydisplay": "Dental_Vendor"
            },
            {
                "primarydisplay": "Dependent_Coverage"
            },
            {
                "primarydisplay": "Diabetes_Services"
            },
            {
                "primarydisplay": "Diabetes_Services_Quick_Tip"
            },
            {
                "primarydisplay": "Diabetes_Supplies"
            },
            {
                "primarydisplay": "Durable_Medical_Equipment"
            },
            {
                "primarydisplay": "Effective_Date"
            },
            {
                "primarydisplay": "Eligibility_Contact"
            },
            {
                "primarydisplay": "Emergency_Health_Services_Outpatient"
            },
            {
                "primarydisplay": "Exclusions"
            },
            {
                "primarydisplay": "Experimental_Investigational_or_Unprove"
            },
            {
                "primarydisplay": "Family_Planning"
            },
            {
                "primarydisplay": "Fertility_Solutions"
            },
            {
                "primarydisplay": "Final_Claim_Fiduciary"
            },
            {
                "primarydisplay": "Flexible_Spending_Account"
            },
            {
                "primarydisplay": "Flexible_Spending_Account_FSA"
            },
            {
                "primarydisplay": "Gender_Identity_Dysphoria_Services"
            },
            {
                "primarydisplay": "Genetic_Testing1"
            },
            {
                "primarydisplay": "Genetic_Testing2"
            },
            {
                "primarydisplay": "Health_Care_Reform"
            },
            {
                "primarydisplay": "Health_Discount_Program"
            },
            {
                "primarydisplay": "Health_Reimbursement_Account_HRA"
            },
            {
                "primarydisplay": "Health_Savings_Account_HSA"
            },
            {
                "primarydisplay": "Health_Wellness"
            },
            {
                "primarydisplay": "Healthy_Pregnancy_Program"
            },
            {
                "primarydisplay": "Hearing_Aids"
            },
            {
                "primarydisplay": "Hemophilia_Program"
            },
            {
                "primarydisplay": "Hemophilia_Quick_Tip"
            },
            {
                "primarydisplay": "Home_Health_Care"
            },
            {
                "primarydisplay": "Hospice_Care"
            },
            {
                "primarydisplay": "Hospital_Inpatient_Stay"
            },
            {
                "primarydisplay": "Hospital_Services"
            },
            {
                "primarydisplay": "Human_Resource_Contact"
            },
            {
                "primarydisplay": "Infertility_Reproductive_Services"
            },
            {
                "primarydisplay": "Kidney_Disease_Programs"
            },
            {
                "primarydisplay": "Lab_XRay_and_Diagnostics_Outpatient"
            },
            {
                "primarydisplay": "Lab_Xray_Diagnostics_Major_CT_PET_MRI"
            },
            {
                "primarydisplay": "Limited_Services_Counting_Method"
            },
            {
                "primarydisplay": "Maternity_Care"
            },
            {
                "primarydisplay": "Mechanical_Circulatory_Support_Devices"
            },
            {
                "primarydisplay": "Medical_Foods"
            },
            {
                "primarydisplay": "Mental_Health_Services_Inpatient"
            },
            {
                "primarydisplay": "Mental_Health_Services_Outpatient"
            },
            {
                "primarydisplay": "Mental_Health_Vendor"
            },
            {
                "primarydisplay": "Mental_and_Nervous"
            },
            {
                "primarydisplay": "Multiple_Surgical_Procedures"
            },
            {
                "primarydisplay": "Neonatal_Resource_Services_NRS"
            },
            {
                "primarydisplay": "Network_Gap"
            },
            {
                "primarydisplay": "NonOffice_Based_Lab_and_Diagnostic_Proce"
            },
            {
                "primarydisplay": "Oral_Surgery"
            },
            {
                "primarydisplay": "Ostomy_Supplies"
            },
            {
                "primarydisplay": "Other_Benefits"
            },
            {
                "primarydisplay": "Out_of_Network_Reimbursement_Programs"
            },
            {
                "primarydisplay": "Out_of_Pocket"
            },
            {
                "primarydisplay": "Out_of_Pocket_Limit"
            },
            {
                "primarydisplay": "Outlier_Cost_Management_OCM"
            },
            {
                "primarydisplay": "OutofPocket_Drug_Limit"
            },
            {
                "primarydisplay": "ParentSteps"
            },
            {
                "primarydisplay": "Per_Occurrence_Deductible"
            },
            {
                "primarydisplay": "Personal_Health_Support"
            },
            {
                "primarydisplay": "Pharmaceutical_Products_Outpatient"
            },
            {
                "primarydisplay": "Pharmaceutical_Products_Quick_Tip"
            },
            {
                "primarydisplay": "Pharmacy_Benefit_Manager_PBM"
            },
            {
                "primarydisplay": "Physician_Fees_for_Surgical_and_Medical"
            },
            {
                "primarydisplay": "Physician_Services"
            },
            {
                "primarydisplay": "Physicians_Office_Services_Sickness_Inju"
            },
            {
                "primarydisplay": "Preexisting_Conditions"
            },
            {
                "primarydisplay": "Pregnancy_Maternity_Services"
            },
            {
                "primarydisplay": "Prescription_Drugs"
            },
            {
                "primarydisplay": "Prescription_Drugs_Mail_Order"
            },
            {
                "primarydisplay": "Prescription_Drugs_Retail"
            },
            {
                "primarydisplay": "Preventive_Care_Services"
            },
            {
                "primarydisplay": "Prior_Authorization"
            },
            {
                "primarydisplay": "Prosthetic_Devices"
            },
            {
                "primarydisplay": "Real_Appeal"
            },
            {
                "primarydisplay": "Reconstructive_Procedures"
            },
            {
                "primarydisplay": "Rehabilitation_and_Habilitative_Services"
            },
            {
                "primarydisplay": "Retiree_Reimbursement_Account_RRA"
            },
            {
                "primarydisplay": "RunIn"
            },
            {
                "primarydisplay": "Scopic_Procedures_Outpatient_Diagnosti"
            },
            {
                "primarydisplay": "SimplyEngaged_Wellness_Incentive_Program"
            },
            {
                "primarydisplay": "Skilled_Nursing_Facility_Inpatient_Rehab"
            },
            {
                "primarydisplay": "Smoking_Cessation"
            },
            {
                "primarydisplay": "Special_Services"
            },
            {
                "primarydisplay": "Specialty_Pharmacy_Program"
            },
            {
                "primarydisplay": "Specialty_Pharmacy_Program_Quick_Tip"
            },
            {
                "primarydisplay": "Step_Therapy"
            },
            {
                "primarydisplay": "Substance_Use_Disorder_Inpatient"
            },
            {
                "primarydisplay": "Substance_Use_Disorder_Outpatient"
            },
            {
                "primarydisplay": "Substance_Use_Vendor"
            },
            {
                "primarydisplay": "Supplemental_Accident"
            },
            {
                "primarydisplay": "Surgery_Outpatient"
            },
            {
                "primarydisplay": "Temporomandibular_Joint_Services"
            },
            {
                "primarydisplay": "Therapeutic_Treatments_Outpatient"
            },
            {
                "primarydisplay": "Transplantation_Services"
            },
            {
                "primarydisplay": "UnitedHealthcare_Motion"
            },
            {
                "primarydisplay": "Urgent_Care_Center_Services"
            },
            {
                "primarydisplay": "Virtual_Visit"
            },
            {
                "primarydisplay": "Vision_Services"
            },
            {
                "primarydisplay": "Vision_Vendor"
            },
            {
                "primarydisplay": "Wigs"
            },
            {
                "primarydisplay": "_DV_C1068"
            },
            {
                "primarydisplay": "hi_healthinnovations_hearing_program"
            }
        ];
    };
    CenterMiddleComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'center-middle',
            template: __webpack_require__(/*! ./center-middle.component.html */ "./src/app/layout-components/center-middle/center-middle.component.html"),
            styles: [__webpack_require__(/*! ./center-middle.component.css */ "./src/app/layout-components/center-middle/center-middle.component.css")]
        }),
        __metadata("design:paramtypes", [src_app_services_rest_call_service__WEBPACK_IMPORTED_MODULE_2__["RestCallService"], src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["DomSanitizer"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])
    ], CenterMiddleComponent);
    return CenterMiddleComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/comapny-logo/company.logo.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/layout-components/comapny-logo/company.logo.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"30\">\n    <amexio-body>\n            <amexio-layout-columns [orientation]=\"'vertical'\" [border]=\"false\" alignment=\"space-between\">\n  <amexio-layout-item [padding]=\"'0px'\" [fit]=\"true\">\n    <amexio-layout-columns [orientation]=\"'horizontal'\" [fit]=\"true\" [border]=\"false\" alignment=\"center\">\n      <amexio-layout-item [padding]=\"'0px'\">\n        <amexio-image   [path]=\"'assets/images/optum.png'\" [filter]=\"'normal'\">\n        </amexio-image>\n      </amexio-layout-item>\n    </amexio-layout-columns>\n  </amexio-layout-item><br>\n \n</amexio-layout-columns>\n    </amexio-body>\n </amexio-card>"

/***/ }),

/***/ "./src/app/layout-components/comapny-logo/company.logo.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/layout-components/comapny-logo/company.logo.component.ts ***!
  \**************************************************************************/
/*! exports provided: CompanyLogoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyLogoComponent", function() { return CompanyLogoComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */


var CompanyLogoComponent = /** @class */ (function () {
    function CompanyLogoComponent(_httpClient) {
        this._httpClient = _httpClient;
    }
    CompanyLogoComponent.prototype.ngOnInit = function () {
    };
    CompanyLogoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'company-logo',
            template: __webpack_require__(/*! ./company.logo.component.html */ "./src/app/layout-components/comapny-logo/company.logo.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], CompanyLogoComponent);
    return CompanyLogoComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/customer-demographic/customer-demographic.component.html":
/*!********************************************************************************************!*\
  !*** ./src/app/layout-components/customer-demographic/customer-demographic.component.html ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"30\">\n  <amexio-body>\n        <b>MEMBER DETAILS</b>\n        <amexio-property-grid [key-value-data]=\"customerKeyValuedata\">\n        </amexio-property-grid>\n  </amexio-body>\n</amexio-card>"

/***/ }),

/***/ "./src/app/layout-components/customer-demographic/customer-demographic.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/layout-components/customer-demographic/customer-demographic.component.ts ***!
  \******************************************************************************************/
/*! exports provided: CustomerDemoGraphicComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDemoGraphicComponent", function() { return CustomerDemoGraphicComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/propertygrid.model */ "./src/app/model/propertygrid.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */



var CustomerDemoGraphicComponent = /** @class */ (function () {
    function CustomerDemoGraphicComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.customerKeyValuedata = [];
        this._sharedService.selectedMember.subscribe(function (data) {
            if (data != null) {
                _this.menberData = data[0];
                _this.updatePropertyStructure();
            }
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.createPropertyStructure();
        });
    }
    CustomerDemoGraphicComponent.prototype.ngOnInit = function () {
        this.createPropertyStructure();
    };
    CustomerDemoGraphicComponent.prototype.ngOnDestroy = function () {
    };
    CustomerDemoGraphicComponent.prototype.createPropertyStructure = function () {
        this.customerKeyValuedata = [];
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('First Name', ''));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Last Name', ''));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('DOB', ''));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Address', ''));
    };
    CustomerDemoGraphicComponent.prototype.updatePropertyStructure = function () {
        this.customerKeyValuedata = [];
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('First Name', this.menberData.firstname));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Last Name', this.menberData.lastname));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('DOB', this.menberData.dob));
        this.customerKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Address', this.menberData.address));
    };
    CustomerDemoGraphicComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customer-demo-graphic',
            template: __webpack_require__(/*! ./customer-demographic.component.html */ "./src/app/layout-components/customer-demographic/customer-demographic.component.html")
        }),
        __metadata("design:paramtypes", [src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], CustomerDemoGraphicComponent);
    return CustomerDemoGraphicComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/product-details/product-details.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/layout-components/product-details/product-details.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-row>\n  <amexio-column [size]=\"6\">\n    <amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"30\">\n      <amexio-body>\n        <b>PLAN DETAILS</b>\n        <amexio-property-grid [key-value-data]=\"productKeyValuedata\">\n        </amexio-property-grid>\n      </amexio-body>\n    </amexio-card>\n\n\n  </amexio-column>\n\n  <amexio-column [size]=\"6\">\n\n    <amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"30\">\n      <amexio-body>\n      </amexio-body>\n    </amexio-card>\n\n\n  </amexio-column>\n</amexio-row>"

/***/ }),

/***/ "./src/app/layout-components/product-details/product-details.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/layout-components/product-details/product-details.component.ts ***!
  \********************************************************************************/
/*! exports provided: ProductDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductDetailsComponent", function() { return ProductDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/shared.service */ "./src/app/services/shared.service.ts");
/* harmony import */ var src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/propertygrid.model */ "./src/app/model/propertygrid.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */



var ProductDetailsComponent = /** @class */ (function () {
    function ProductDetailsComponent(_sharedService) {
        var _this = this;
        this._sharedService = _sharedService;
        this.productData = [];
        this._sharedService.selectedMember.subscribe(function (data) {
            if (data != null) {
                _this.productData = data[0];
                _this.updatePropertyStructure();
            }
        });
        this._sharedService.resetDetails.subscribe(function (data) {
            _this.createPropertyStructure();
        });
    }
    ProductDetailsComponent.prototype.ngOnInit = function () {
        this.createPropertyStructure();
    };
    ProductDetailsComponent.prototype.ngOnDestroy = function () {
    };
    ProductDetailsComponent.prototype.createPropertyStructure = function () {
        this.productKeyValuedata = [];
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Policy no.', ''));
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Effective Date', ''));
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Name', ''));
    };
    ProductDetailsComponent.prototype.updatePropertyStructure = function () {
        this.productKeyValuedata = [];
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Policy no.', this.productData.policynumber));
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Effective Date', this.productData.effectivedate));
        this.productKeyValuedata.push(new src_app_model_propertygrid_model__WEBPACK_IMPORTED_MODULE_2__["PropertyModel"]('Plan Name', this.productData.planname));
    };
    ProductDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'product-detail',
            template: __webpack_require__(/*! ./product-details.component.html */ "./src/app/layout-components/product-details/product-details.component.html")
        }),
        __metadata("design:paramtypes", [src_app_services_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"]])
    ], ProductDetailsComponent);
    return ProductDetailsComponent;
}());



/***/ }),

/***/ "./src/app/layout-components/top-right/top-right.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/layout-components/top-right/top-right.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<amexio-card [header]=\"false\" [footer]=\"false\" [body-height]=\"30\">\n  <amexio-body>\n    <div style=\"text-align: center;\">\n      <b>{{date | date : 'short'}}</b>\n    </div>\n    <br />\n    <amexio-row>\n      <amexio-column size=\"6\" style=\"text-align: center;\">\n        <amexio-dashboard-gauge [data]=\"guagedata\" [red-color-from]=\"90\" [red-color-to]=\"100\" [yellow-color-from]=\"75\"\n          [yellow-color-to]=\"90\" [scale-value]=\"5\">\n        </amexio-dashboard-gauge>\n        <b>CSAT 70/100%</b>\n      </amexio-column>\n      <amexio-column size=\"6\" style=\"text-align: center;\" *ngIf=\"showguage\">\n        <amexio-dashboard-gauge [data]=\"guagedataone\" [red-color-from]=\"90\" [red-color-to]=\"100\"\n          [yellow-color-from]=\"75\" [yellow-color-to]=\"90\" [scale-value]=\"5\">\n        </amexio-dashboard-gauge>\n        <b>AHT SLA 200</b>\n      </amexio-column>\n    </amexio-row>\n    \n    <amexio-row>\n      <amexio-column size=\"12\">\n        <div style=\"display: inline-flex; justify-content: center; width:100%;cursor:pointer\">\n          <i *ngIf=\"_sharedService.showAlert\" class=\"fa fa-exclamation-triangle fa-2x\"  style=\"color: var(--themeSecondaryColor);\" (click)=\"onAlertClick()\"></i>\n        </div>\n      </amexio-column>\n    </amexio-row>\n  </amexio-body>\n</amexio-card>"

/***/ }),

/***/ "./src/app/layout-components/top-right/top-right.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/layout-components/top-right/top-right.component.ts ***!
  \********************************************************************/
/*! exports provided: TopRightComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopRightComponent", function() { return TopRightComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _services_shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/shared.service */ "./src/app/services/shared.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by ashwini on 24/7/19.
 */



var TopRightComponent = /** @class */ (function () {
    function TopRightComponent(_httpClient, _sharedService) {
        this._httpClient = _httpClient;
        this._sharedService = _sharedService;
        this.uiLoadingCount = [];
        this.confirmdialogue = false;
        this.showguage = false;
        this.guagedata = [
            ['Label', 'Value'],
            ['CSAT', 80]
        ];
        this.guagedataone = [
            ['Label', 'Value'],
            ['AHT-SLA', 68]
        ];
    }
    TopRightComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.showguage = true;
            _this.startTimer();
        }, 500);
    };
    TopRightComponent.prototype.startTimer = function () {
        this.date = new Date();
    };
    TopRightComponent.prototype.onAlertClick = function () {
        this._sharedService.showAlertWindow = true;
    };
    TopRightComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'top-right',
            template: __webpack_require__(/*! ./top-right.component.html */ "./src/app/layout-components/top-right/top-right.component.html")
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _services_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"]])
    ], TopRightComponent);
    return TopRightComponent;
}());



/***/ }),

/***/ "./src/app/model/propertygrid.model.ts":
/*!*********************************************!*\
  !*** ./src/app/model/propertygrid.model.ts ***!
  \*********************************************/
/*! exports provided: PropertyModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PropertyModel", function() { return PropertyModel; });
var PropertyModel = /** @class */ (function () {
    function PropertyModel(_fieldName, _fieldValue) {
        this.fieldName = _fieldName;
        this.fieldValue = _fieldValue;
    }
    return PropertyModel;
}());



/***/ }),

/***/ "./src/app/model/searchm.model.ts":
/*!****************************************!*\
  !*** ./src/app/model/searchm.model.ts ***!
  \****************************************/
/*! exports provided: SearchModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModel", function() { return SearchModel; });
var SearchModel = /** @class */ (function () {
    function SearchModel() {
        this.memberId = '';
        this.firstName = '';
        this.lastName = '';
        this.dob = '';
    }
    return SearchModel;
}());



/***/ }),

/***/ "./src/app/services/rest.call.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/rest.call.service.ts ***!
  \***********************************************/
/*! exports provided: RestCallService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RestCallService", function() { return RestCallService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RestCallService = /** @class */ (function () {
    function RestCallService(http) {
        this.http = http;
    }
    RestCallService.prototype.postCall = function (serviceUrl, methodType, requestJson) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().append('Content-Type', 'application/x-www-form-urlencoded');
        if (methodType === 'post') {
            return this.http.post(serviceUrl, requestJson, { headers: headers });
        }
    };
    RestCallService.prototype.getCall = function (serviceUrl, requestJson) {
        console.log(JSON.stringify(requestJson.Data));
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]().append('Content-Type', 'application/x-www-form-urlencoded');
        var newsrurl = serviceUrl + "?initial=" + requestJson.Initial + "&data=" + encodeURIComponent(JSON.stringify(requestJson.Data));
        console.log(" URL Payload : " + newsrurl);
        return this.http.post(newsrurl, { headers: headers });
    };
    RestCallService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], RestCallService);
    return RestCallService;
}());



/***/ }),

/***/ "./src/app/services/shared.service.ts":
/*!********************************************!*\
  !*** ./src/app/services/shared.service.ts ***!
  \********************************************/
/*! exports provided: SharedService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedService", function() { return SharedService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SharedService = /** @class */ (function () {
    function SharedService() {
        this.showLoader = false;
        this.showAlert = false;
        this.searchdisble = false;
        this.errorMsgData = [];
        this.searchResponse = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.selectedMember = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.claimsData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.selectMember = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false);
        this.originatorData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.rejectedClaimData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.showAlertWindow = false;
        this.resetDetails = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.padata = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.ibaagResponse = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.icueData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.passData = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
    }
    SharedService.prototype.addSearchResponse = function (response) {
        if (response.Data.ResponseStatus.Success || response.Data.ResponseStatus.success) {
            console.log(JSON.stringify(response));
            var cd = this.covertData(response);
            this.searchResponse.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(response.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.resetData = function () {
        var data = [];
        this.resetDetails.next(data);
    };
    SharedService.prototype.addSelectedMember = function (memberDetails) {
        if (memberDetails.Data.ResponseStatus.Success || memberDetails.Data.ResponseStatus.success) {
            console.log(JSON.stringify(memberDetails));
            var cd = this.covertData(memberDetails);
            this.selectedMember.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(memberDetails.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.updateSelectMemberFlag = function (value) {
        this.selectMember.next(value);
    };
    SharedService.prototype.setClaimsData = function (claims) {
        if (claims.Data.ResponseStatus.Success || claims.Data.ResponseStatus.success) {
            console.log(JSON.stringify(claims));
            var cd = this.covertData(claims);
            this.claimsData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(claims.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getRejectedClaims = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.rejectedClaimData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.findoriginator = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.originatorData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getClaimActionData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.ibaagResponse.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getPaData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.padata.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getICUEData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.icueData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    SharedService.prototype.getpassData = function (data) {
        if (data.Data.ResponseStatus.Success || data.Data.ResponseStatus.success) {
            console.log(JSON.stringify(data));
            var cd = this.covertData(data);
            this.passData.next(cd.data.responsedata);
        }
        else {
            this.errorMsgData.push(data.Data.ResponseStatus.statusMessage);
            this.showLoader = false;
        }
    };
    /* Convert Key into lowercase */
    SharedService.prototype.covertData = function (response) {
        var _this = this;
        return Object.keys(response)
            .reduce(function (destination, key) {
            destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()] = response[key];
            var data = destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()];
            if (typeof (data) === 'object' && data.length !== undefined && data.length > 0) {
                data.forEach(function (obj, index) {
                    if (typeof (obj) === 'object') {
                        data[index] = _this.covertData(obj);
                    }
                });
            }
            else if (data && (data.length == undefined)) {
                destination[key.replace(/[^A-Z0-9]+/ig, '').toLowerCase()] = _this.covertData(data);
            }
            return destination;
        }, {});
    };
    SharedService.prototype.getRequestId = function () {
        return new Date().getTime() + Math.floor(Math.random() * 100 + 1);
    };
    SharedService.prototype.getRequestTime = function () {
        return new Date().getTime();
    };
    SharedService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], SharedService);
    return SharedService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/ashwini/gic-rina-poc/OPTUM-POC/gic-optum/EandI/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map